--
-- PostgreSQL database dump
--

\restrict xJcy8HUzLOV5mp6tcQPdHFKVxHcFXfQR8kcFWw3Ks8BQPhRlUbg4ZXAlyMhI1QC

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: platform; Type: SCHEMA; Schema: -; Owner: app_advertisement
--

CREATE SCHEMA platform;


ALTER SCHEMA platform OWNER TO app_advertisement;

--
-- Name: t_exemplo; Type: SCHEMA; Schema: -; Owner: app_advertisement
--

CREATE SCHEMA t_exemplo;


ALTER SCHEMA t_exemplo OWNER TO app_advertisement;

--
-- Name: t_iuri; Type: SCHEMA; Schema: -; Owner: app_advertisement
--

CREATE SCHEMA t_iuri;


ALTER SCHEMA t_iuri OWNER TO app_advertisement;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: demo_lead; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.demo_lead (
    id bigint NOT NULL,
    session_id uuid NOT NULL,
    kind character varying(10) NOT NULL,
    value character varying(254) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_demo_lead_kind CHECK (((kind)::text = ANY ((ARRAY['email'::character varying, 'whatsapp'::character varying])::text[])))
);


ALTER TABLE platform.demo_lead OWNER TO app_advertisement;

--
-- Name: demo_lead_id_seq; Type: SEQUENCE; Schema: platform; Owner: app_advertisement
--

CREATE SEQUENCE platform.demo_lead_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE platform.demo_lead_id_seq OWNER TO app_advertisement;

--
-- Name: demo_lead_id_seq; Type: SEQUENCE OWNED BY; Schema: platform; Owner: app_advertisement
--

ALTER SEQUENCE platform.demo_lead_id_seq OWNED BY platform.demo_lead.id;


--
-- Name: demo_login_token; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.demo_login_token (
    token_hash character(64) NOT NULL,
    session_id uuid NOT NULL,
    role character varying(40) NOT NULL,
    username character varying(80) NOT NULL,
    reusable boolean DEFAULT false NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone
);


ALTER TABLE platform.demo_login_token OWNER TO app_advertisement;

--
-- Name: demo_sandbox; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.demo_sandbox (
    tenant_id bigint NOT NULL,
    kind character varying(10) NOT NULL,
    seeded_at timestamp with time zone,
    assigned_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_demo_sandbox_kind CHECK (((kind)::text = ANY ((ARRAY['template'::character varying, 'pooled'::character varying, 'assigned'::character varying])::text[])))
);


ALTER TABLE platform.demo_sandbox OWNER TO app_advertisement;

--
-- Name: demo_session; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.demo_session (
    id uuid NOT NULL,
    tenant_id bigint,
    slug character varying(40) NOT NULL,
    origin character varying(10) NOT NULL,
    prospect_name character varying(200),
    ip_hash character(64),
    lead_kind character varying(10),
    lead_value character varying(254),
    extendable boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    extended_at timestamp with time zone,
    ended_at timestamp with time zone,
    end_reason character varying(10),
    CONSTRAINT ck_demo_session_end_reason CHECK (((end_reason IS NULL) OR ((end_reason)::text = ANY ((ARRAY['expired'::character varying, 'ended'::character varying, 'swept'::character varying])::text[])))),
    CONSTRAINT ck_demo_session_origin CHECK (((origin)::text = ANY ((ARRAY['visitor'::character varying, 'owner'::character varying])::text[])))
);


ALTER TABLE platform.demo_session OWNER TO app_advertisement;

--
-- Name: demo_settings; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.demo_settings (
    id smallint NOT NULL,
    enabled boolean NOT NULL,
    duration_minutes integer NOT NULL,
    extension_enabled boolean NOT NULL,
    extension_minutes integer NOT NULL,
    pool_size integer NOT NULL,
    rate_limit_per_ip_per_hour integer NOT NULL,
    max_live_sandboxes integer NOT NULL,
    lead_enabled boolean NOT NULL,
    cta_enabled boolean NOT NULL,
    cta_label character varying(60),
    cta_url character varying(500),
    welcome_intro_enabled boolean NOT NULL,
    welcome_intro character varying(1000),
    owner_validity_hours integer NOT NULL,
    upload_limit_enabled boolean NOT NULL,
    upload_limit_kb integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT demo_settings_id_check CHECK ((id = 1))
);


ALTER TABLE platform.demo_settings OWNER TO app_advertisement;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE platform.flyway_schema_history OWNER TO app_advertisement;

--
-- Name: google_login_ticket; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.google_login_ticket (
    ticket_hash character(64) NOT NULL,
    tenant_slug character varying(40) NOT NULL,
    binding_hash character(64) NOT NULL,
    sub character varying(255) NOT NULL,
    email character varying(254) NOT NULL,
    name character varying(300),
    picture character varying(1000),
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE platform.google_login_ticket OWNER TO app_advertisement;

--
-- Name: tenant; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.tenant (
    id bigint NOT NULL,
    slug character varying(40) NOT NULL,
    schema_name character varying(60) NOT NULL,
    name character varying(200) NOT NULL,
    status character varying(20) NOT NULL,
    central_customer_id character varying(80),
    central_subscription_id character varying(80),
    plan_code character varying(80),
    admin_email character varying(254),
    admin_provisioned_at timestamp with time zone,
    trial_ends_at timestamp with time zone,
    current_period_end timestamp with time zone,
    suspended_at timestamp with time zone,
    delete_after timestamp with time zone,
    entitlements_json text,
    entitlements_etag character varying(120),
    entitlements_fetched_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_tenant_status CHECK (((status)::text = ANY ((ARRAY['provisioning'::character varying, 'trialing'::character varying, 'active'::character varying, 'past_due'::character varying, 'suspended'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE platform.tenant OWNER TO app_advertisement;

--
-- Name: tenant_domain; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.tenant_domain (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    host character varying(253) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE platform.tenant_domain OWNER TO app_advertisement;

--
-- Name: tenant_domain_id_seq; Type: SEQUENCE; Schema: platform; Owner: app_advertisement
--

CREATE SEQUENCE platform.tenant_domain_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE platform.tenant_domain_id_seq OWNER TO app_advertisement;

--
-- Name: tenant_domain_id_seq; Type: SEQUENCE OWNED BY; Schema: platform; Owner: app_advertisement
--

ALTER SEQUENCE platform.tenant_domain_id_seq OWNED BY platform.tenant_domain.id;


--
-- Name: tenant_event; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.tenant_event (
    event_id character varying(120) NOT NULL,
    type character varying(80) NOT NULL,
    payload text NOT NULL,
    status character varying(10) DEFAULT 'received'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    last_attempt_at timestamp with time zone,
    processed_at timestamp with time zone,
    CONSTRAINT ck_tenant_event_status CHECK (((status)::text = ANY ((ARRAY['received'::character varying, 'processed'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE platform.tenant_event OWNER TO app_advertisement;

--
-- Name: tenant_host_cert; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.tenant_host_cert (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    host character varying(253) NOT NULL,
    custom boolean DEFAULT false NOT NULL,
    status character varying(10) DEFAULT 'pending'::character varying NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    ready_at timestamp with time zone,
    CONSTRAINT ck_tenant_host_cert_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'ready'::character varying])::text[])))
);


ALTER TABLE platform.tenant_host_cert OWNER TO app_advertisement;

--
-- Name: tenant_host_cert_id_seq; Type: SEQUENCE; Schema: platform; Owner: app_advertisement
--

CREATE SEQUENCE platform.tenant_host_cert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE platform.tenant_host_cert_id_seq OWNER TO app_advertisement;

--
-- Name: tenant_host_cert_id_seq; Type: SEQUENCE OWNED BY; Schema: platform; Owner: app_advertisement
--

ALTER SEQUENCE platform.tenant_host_cert_id_seq OWNED BY platform.tenant_host_cert.id;


--
-- Name: tenant_id_seq; Type: SEQUENCE; Schema: platform; Owner: app_advertisement
--

CREATE SEQUENCE platform.tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE platform.tenant_id_seq OWNER TO app_advertisement;

--
-- Name: tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: platform; Owner: app_advertisement
--

ALTER SEQUENCE platform.tenant_id_seq OWNED BY platform.tenant.id;


--
-- Name: turnstile_settings; Type: TABLE; Schema: platform; Owner: app_advertisement
--

CREATE TABLE platform.turnstile_settings (
    id smallint NOT NULL,
    enabled boolean NOT NULL,
    site_key character varying(200),
    secret_key character varying(200),
    extra_paths_enabled boolean NOT NULL,
    extra_paths text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT turnstile_settings_id_check CHECK ((id = 1))
);


ALTER TABLE platform.turnstile_settings OWNER TO app_advertisement;

--
-- Name: app_setting; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.app_setting (
    id bigint NOT NULL,
    offline_after_seconds integer NOT NULL,
    heartbeat_seconds integer NOT NULL,
    history_retention_enabled boolean NOT NULL,
    history_retention_days integer,
    updated_at timestamp with time zone NOT NULL,
    auto_send_enabled boolean DEFAULT false NOT NULL,
    live_preview_enabled boolean DEFAULT true NOT NULL,
    live_preview_seconds integer DEFAULT 5 NOT NULL,
    periodic_snapshot_enabled boolean DEFAULT false NOT NULL,
    periodic_snapshot_minutes integer DEFAULT 15 NOT NULL
);


ALTER TABLE t_exemplo.app_setting OWNER TO app_advertisement;

--
-- Name: app_setting_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.app_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.app_setting_id_seq OWNER TO app_advertisement;

--
-- Name: app_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.app_setting_id_seq OWNED BY t_exemplo.app_setting.id;


--
-- Name: app_user; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.app_user (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    email character varying(160) NOT NULL,
    password_hash character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    password_defined boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.app_user OWNER TO app_advertisement;

--
-- Name: app_user_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.app_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.app_user_id_seq OWNER TO app_advertisement;

--
-- Name: app_user_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.app_user_id_seq OWNED BY t_exemplo.app_user.id;


--
-- Name: delivery; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.delivery (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    revision character varying(64) NOT NULL,
    manifest jsonb,
    media_ids jsonb NOT NULL,
    status character varying(20) NOT NULL,
    bytes_done bigint NOT NULL,
    bytes_total bigint NOT NULL,
    current_media character varying(200),
    failure_reason character varying(500),
    fk_id_sentby bigint,
    created_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.delivery OWNER TO app_advertisement;

--
-- Name: delivery_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.delivery_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.delivery_id_seq OWNER TO app_advertisement;

--
-- Name: delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.delivery_id_seq OWNED BY t_exemplo.delivery.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE t_exemplo.flyway_schema_history OWNER TO app_advertisement;

--
-- Name: media; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.media (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    kind character varying(10) NOT NULL,
    mime_type character varying(100) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    duration_seconds integer NOT NULL,
    width integer,
    height integer,
    stored_file character varying(80) NOT NULL,
    poster_file character varying(80),
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.media OWNER TO app_advertisement;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.media_id_seq OWNER TO app_advertisement;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.media_id_seq OWNED BY t_exemplo.media.id;


--
-- Name: media_upload; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.media_upload (
    id bigint NOT NULL,
    upload_key character varying(40) NOT NULL,
    name character varying(200) NOT NULL,
    mime_type character varying(100) NOT NULL,
    size_bytes bigint NOT NULL,
    received_bytes bigint NOT NULL,
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.media_upload OWNER TO app_advertisement;

--
-- Name: media_upload_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.media_upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.media_upload_id_seq OWNER TO app_advertisement;

--
-- Name: media_upload_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.media_upload_id_seq OWNED BY t_exemplo.media_upload.id;


--
-- Name: password_token; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.password_token (
    id bigint NOT NULL,
    fk_id_user bigint NOT NULL,
    token_hash character varying(64) NOT NULL,
    purpose character varying(20) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.password_token OWNER TO app_advertisement;

--
-- Name: password_token_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.password_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.password_token_id_seq OWNER TO app_advertisement;

--
-- Name: password_token_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.password_token_id_seq OWNED BY t_exemplo.password_token.id;


--
-- Name: playlist; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.playlist (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    interval_seconds integer NOT NULL,
    items jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mini jsonb,
    rotation_epoch integer DEFAULT 0 NOT NULL,
    fk_id_originscreen bigint,
    origin_local_id character varying(100),
    imported_at timestamp with time zone,
    edited_since_import boolean DEFAULT false NOT NULL
);


ALTER TABLE t_exemplo.playlist OWNER TO app_advertisement;

--
-- Name: playlist_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.playlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.playlist_id_seq OWNER TO app_advertisement;

--
-- Name: playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.playlist_id_seq OWNED BY t_exemplo.playlist.id;


--
-- Name: schedule; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.schedule (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_playlist bigint NOT NULL,
    days_of_week jsonb NOT NULL,
    start_time character varying(5) NOT NULL,
    end_time character varying(5) NOT NULL,
    priority integer NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    fk_id_originscreen bigint,
    origin_local_id character varying(100)
);


ALTER TABLE t_exemplo.schedule OWNER TO app_advertisement;

--
-- Name: schedule_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.schedule_id_seq OWNER TO app_advertisement;

--
-- Name: schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.schedule_id_seq OWNED BY t_exemplo.schedule.id;


--
-- Name: screen; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.screen (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_group bigint,
    token_hash character varying(64) NOT NULL,
    device_id character varying(64) NOT NULL,
    platform character varying(20),
    app_version character varying(30),
    orientation integer,
    resolution character varying(30),
    last_seen_at timestamp with time zone,
    now_playing jsonb,
    disk_free_bytes bigint,
    disk_total_bytes bigint,
    own_programming boolean NOT NULL,
    fk_id_defaultplaylist bigint,
    schedule_ids jsonb NOT NULL,
    fk_id_currentdelivery bigint,
    applied_revision character varying(64),
    inventory_reported_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    local_content jsonb,
    local_content_at timestamp with time zone,
    attention_until timestamp with time zone,
    latest_app_version character varying(30),
    edition character varying(20),
    preview_until timestamp with time zone
);


ALTER TABLE t_exemplo.screen OWNER TO app_advertisement;

--
-- Name: screen_command; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.screen_command (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    type character varying(30) NOT NULL,
    argument character varying(250),
    status character varying(20) NOT NULL,
    result_message character varying(500),
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    duration_minutes integer,
    result_ref character varying(1000)
);


ALTER TABLE t_exemplo.screen_command OWNER TO app_advertisement;

--
-- Name: screen_command_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.screen_command_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.screen_command_id_seq OWNER TO app_advertisement;

--
-- Name: screen_command_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.screen_command_id_seq OWNED BY t_exemplo.screen_command.id;


--
-- Name: screen_group; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.screen_group (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_defaultplaylist bigint,
    schedule_ids jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.screen_group OWNER TO app_advertisement;

--
-- Name: screen_group_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.screen_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.screen_group_id_seq OWNER TO app_advertisement;

--
-- Name: screen_group_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.screen_group_id_seq OWNED BY t_exemplo.screen_group.id;


--
-- Name: screen_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.screen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.screen_id_seq OWNER TO app_advertisement;

--
-- Name: screen_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.screen_id_seq OWNED BY t_exemplo.screen.id;


--
-- Name: screen_media; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.screen_media (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    local_id character varying(80) NOT NULL,
    media_id bigint,
    name character varying(250) NOT NULL,
    size_bytes bigint NOT NULL,
    in_use boolean NOT NULL,
    from_server boolean NOT NULL
);


ALTER TABLE t_exemplo.screen_media OWNER TO app_advertisement;

--
-- Name: screen_media_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.screen_media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.screen_media_id_seq OWNER TO app_advertisement;

--
-- Name: screen_media_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.screen_media_id_seq OWNED BY t_exemplo.screen_media.id;


--
-- Name: screen_snapshot; Type: TABLE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE TABLE t_exemplo.screen_snapshot (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    image bytea NOT NULL,
    size_bytes integer NOT NULL,
    media_local_id character varying(100),
    captured_at timestamp with time zone NOT NULL
);


ALTER TABLE t_exemplo.screen_snapshot OWNER TO app_advertisement;

--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE; Schema: t_exemplo; Owner: app_advertisement
--

CREATE SEQUENCE t_exemplo.screen_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_exemplo.screen_snapshot_id_seq OWNER TO app_advertisement;

--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: t_exemplo; Owner: app_advertisement
--

ALTER SEQUENCE t_exemplo.screen_snapshot_id_seq OWNED BY t_exemplo.screen_snapshot.id;


--
-- Name: app_setting; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.app_setting (
    id bigint NOT NULL,
    offline_after_seconds integer NOT NULL,
    heartbeat_seconds integer NOT NULL,
    history_retention_enabled boolean NOT NULL,
    history_retention_days integer,
    updated_at timestamp with time zone NOT NULL,
    auto_send_enabled boolean DEFAULT false NOT NULL,
    live_preview_enabled boolean DEFAULT true NOT NULL,
    live_preview_seconds integer DEFAULT 5 NOT NULL,
    periodic_snapshot_enabled boolean DEFAULT false NOT NULL,
    periodic_snapshot_minutes integer DEFAULT 15 NOT NULL
);


ALTER TABLE t_iuri.app_setting OWNER TO app_advertisement;

--
-- Name: app_setting_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.app_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.app_setting_id_seq OWNER TO app_advertisement;

--
-- Name: app_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.app_setting_id_seq OWNED BY t_iuri.app_setting.id;


--
-- Name: app_user; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.app_user (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    email character varying(160) NOT NULL,
    password_hash character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    password_defined boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.app_user OWNER TO app_advertisement;

--
-- Name: app_user_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.app_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.app_user_id_seq OWNER TO app_advertisement;

--
-- Name: app_user_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.app_user_id_seq OWNED BY t_iuri.app_user.id;


--
-- Name: delivery; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.delivery (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    revision character varying(64) NOT NULL,
    manifest jsonb,
    media_ids jsonb NOT NULL,
    status character varying(20) NOT NULL,
    bytes_done bigint NOT NULL,
    bytes_total bigint NOT NULL,
    current_media character varying(200),
    failure_reason character varying(500),
    fk_id_sentby bigint,
    created_at timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.delivery OWNER TO app_advertisement;

--
-- Name: delivery_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.delivery_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.delivery_id_seq OWNER TO app_advertisement;

--
-- Name: delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.delivery_id_seq OWNED BY t_iuri.delivery.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE t_iuri.flyway_schema_history OWNER TO app_advertisement;

--
-- Name: media; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.media (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    kind character varying(10) NOT NULL,
    mime_type character varying(100) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    duration_seconds integer NOT NULL,
    width integer,
    height integer,
    stored_file character varying(80) NOT NULL,
    poster_file character varying(80),
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.media OWNER TO app_advertisement;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.media_id_seq OWNER TO app_advertisement;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.media_id_seq OWNED BY t_iuri.media.id;


--
-- Name: media_upload; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.media_upload (
    id bigint NOT NULL,
    upload_key character varying(40) NOT NULL,
    name character varying(200) NOT NULL,
    mime_type character varying(100) NOT NULL,
    size_bytes bigint NOT NULL,
    received_bytes bigint NOT NULL,
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.media_upload OWNER TO app_advertisement;

--
-- Name: media_upload_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.media_upload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.media_upload_id_seq OWNER TO app_advertisement;

--
-- Name: media_upload_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.media_upload_id_seq OWNED BY t_iuri.media_upload.id;


--
-- Name: password_token; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.password_token (
    id bigint NOT NULL,
    fk_id_user bigint NOT NULL,
    token_hash character varying(64) NOT NULL,
    purpose character varying(20) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.password_token OWNER TO app_advertisement;

--
-- Name: password_token_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.password_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.password_token_id_seq OWNER TO app_advertisement;

--
-- Name: password_token_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.password_token_id_seq OWNED BY t_iuri.password_token.id;


--
-- Name: playlist; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.playlist (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    interval_seconds integer NOT NULL,
    items jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mini jsonb,
    rotation_epoch integer DEFAULT 0 NOT NULL,
    fk_id_originscreen bigint,
    origin_local_id character varying(100),
    imported_at timestamp with time zone,
    edited_since_import boolean DEFAULT false NOT NULL
);


ALTER TABLE t_iuri.playlist OWNER TO app_advertisement;

--
-- Name: playlist_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.playlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.playlist_id_seq OWNER TO app_advertisement;

--
-- Name: playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.playlist_id_seq OWNED BY t_iuri.playlist.id;


--
-- Name: schedule; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.schedule (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_playlist bigint NOT NULL,
    days_of_week jsonb NOT NULL,
    start_time character varying(5) NOT NULL,
    end_time character varying(5) NOT NULL,
    priority integer NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    fk_id_originscreen bigint,
    origin_local_id character varying(100)
);


ALTER TABLE t_iuri.schedule OWNER TO app_advertisement;

--
-- Name: schedule_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.schedule_id_seq OWNER TO app_advertisement;

--
-- Name: schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.schedule_id_seq OWNED BY t_iuri.schedule.id;


--
-- Name: screen; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.screen (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_group bigint,
    token_hash character varying(64) NOT NULL,
    device_id character varying(64) NOT NULL,
    platform character varying(20),
    app_version character varying(30),
    orientation integer,
    resolution character varying(30),
    last_seen_at timestamp with time zone,
    now_playing jsonb,
    disk_free_bytes bigint,
    disk_total_bytes bigint,
    own_programming boolean NOT NULL,
    fk_id_defaultplaylist bigint,
    schedule_ids jsonb NOT NULL,
    fk_id_currentdelivery bigint,
    applied_revision character varying(64),
    inventory_reported_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    local_content jsonb,
    local_content_at timestamp with time zone,
    attention_until timestamp with time zone,
    latest_app_version character varying(30),
    edition character varying(20),
    preview_until timestamp with time zone
);


ALTER TABLE t_iuri.screen OWNER TO app_advertisement;

--
-- Name: screen_command; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.screen_command (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    type character varying(30) NOT NULL,
    argument character varying(250),
    status character varying(20) NOT NULL,
    result_message character varying(500),
    fk_id_createdby bigint,
    created_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    duration_minutes integer,
    result_ref character varying(1000)
);


ALTER TABLE t_iuri.screen_command OWNER TO app_advertisement;

--
-- Name: screen_command_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.screen_command_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.screen_command_id_seq OWNER TO app_advertisement;

--
-- Name: screen_command_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.screen_command_id_seq OWNED BY t_iuri.screen_command.id;


--
-- Name: screen_group; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.screen_group (
    id bigint NOT NULL,
    name character varying(120) NOT NULL,
    fk_id_defaultplaylist bigint,
    schedule_ids jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.screen_group OWNER TO app_advertisement;

--
-- Name: screen_group_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.screen_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.screen_group_id_seq OWNER TO app_advertisement;

--
-- Name: screen_group_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.screen_group_id_seq OWNED BY t_iuri.screen_group.id;


--
-- Name: screen_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.screen_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.screen_id_seq OWNER TO app_advertisement;

--
-- Name: screen_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.screen_id_seq OWNED BY t_iuri.screen.id;


--
-- Name: screen_media; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.screen_media (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    local_id character varying(80) NOT NULL,
    media_id bigint,
    name character varying(250) NOT NULL,
    size_bytes bigint NOT NULL,
    in_use boolean NOT NULL,
    from_server boolean NOT NULL
);


ALTER TABLE t_iuri.screen_media OWNER TO app_advertisement;

--
-- Name: screen_media_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.screen_media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.screen_media_id_seq OWNER TO app_advertisement;

--
-- Name: screen_media_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.screen_media_id_seq OWNED BY t_iuri.screen_media.id;


--
-- Name: screen_snapshot; Type: TABLE; Schema: t_iuri; Owner: app_advertisement
--

CREATE TABLE t_iuri.screen_snapshot (
    id bigint NOT NULL,
    fk_id_screen bigint NOT NULL,
    image bytea NOT NULL,
    size_bytes integer NOT NULL,
    media_local_id character varying(100),
    captured_at timestamp with time zone NOT NULL
);


ALTER TABLE t_iuri.screen_snapshot OWNER TO app_advertisement;

--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE; Schema: t_iuri; Owner: app_advertisement
--

CREATE SEQUENCE t_iuri.screen_snapshot_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t_iuri.screen_snapshot_id_seq OWNER TO app_advertisement;

--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: t_iuri; Owner: app_advertisement
--

ALTER SEQUENCE t_iuri.screen_snapshot_id_seq OWNED BY t_iuri.screen_snapshot.id;


--
-- Name: demo_lead id; Type: DEFAULT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_lead ALTER COLUMN id SET DEFAULT nextval('platform.demo_lead_id_seq'::regclass);


--
-- Name: tenant id; Type: DEFAULT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant ALTER COLUMN id SET DEFAULT nextval('platform.tenant_id_seq'::regclass);


--
-- Name: tenant_domain id; Type: DEFAULT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_domain ALTER COLUMN id SET DEFAULT nextval('platform.tenant_domain_id_seq'::regclass);


--
-- Name: tenant_host_cert id; Type: DEFAULT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_host_cert ALTER COLUMN id SET DEFAULT nextval('platform.tenant_host_cert_id_seq'::regclass);


--
-- Name: app_setting id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.app_setting ALTER COLUMN id SET DEFAULT nextval('t_exemplo.app_setting_id_seq'::regclass);


--
-- Name: app_user id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.app_user ALTER COLUMN id SET DEFAULT nextval('t_exemplo.app_user_id_seq'::regclass);


--
-- Name: delivery id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.delivery ALTER COLUMN id SET DEFAULT nextval('t_exemplo.delivery_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media ALTER COLUMN id SET DEFAULT nextval('t_exemplo.media_id_seq'::regclass);


--
-- Name: media_upload id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media_upload ALTER COLUMN id SET DEFAULT nextval('t_exemplo.media_upload_id_seq'::regclass);


--
-- Name: password_token id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.password_token ALTER COLUMN id SET DEFAULT nextval('t_exemplo.password_token_id_seq'::regclass);


--
-- Name: playlist id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.playlist ALTER COLUMN id SET DEFAULT nextval('t_exemplo.playlist_id_seq'::regclass);


--
-- Name: schedule id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.schedule ALTER COLUMN id SET DEFAULT nextval('t_exemplo.schedule_id_seq'::regclass);


--
-- Name: screen id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen ALTER COLUMN id SET DEFAULT nextval('t_exemplo.screen_id_seq'::regclass);


--
-- Name: screen_command id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_command ALTER COLUMN id SET DEFAULT nextval('t_exemplo.screen_command_id_seq'::regclass);


--
-- Name: screen_group id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_group ALTER COLUMN id SET DEFAULT nextval('t_exemplo.screen_group_id_seq'::regclass);


--
-- Name: screen_media id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_media ALTER COLUMN id SET DEFAULT nextval('t_exemplo.screen_media_id_seq'::regclass);


--
-- Name: screen_snapshot id; Type: DEFAULT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_snapshot ALTER COLUMN id SET DEFAULT nextval('t_exemplo.screen_snapshot_id_seq'::regclass);


--
-- Name: app_setting id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.app_setting ALTER COLUMN id SET DEFAULT nextval('t_iuri.app_setting_id_seq'::regclass);


--
-- Name: app_user id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.app_user ALTER COLUMN id SET DEFAULT nextval('t_iuri.app_user_id_seq'::regclass);


--
-- Name: delivery id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.delivery ALTER COLUMN id SET DEFAULT nextval('t_iuri.delivery_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media ALTER COLUMN id SET DEFAULT nextval('t_iuri.media_id_seq'::regclass);


--
-- Name: media_upload id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media_upload ALTER COLUMN id SET DEFAULT nextval('t_iuri.media_upload_id_seq'::regclass);


--
-- Name: password_token id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.password_token ALTER COLUMN id SET DEFAULT nextval('t_iuri.password_token_id_seq'::regclass);


--
-- Name: playlist id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.playlist ALTER COLUMN id SET DEFAULT nextval('t_iuri.playlist_id_seq'::regclass);


--
-- Name: schedule id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.schedule ALTER COLUMN id SET DEFAULT nextval('t_iuri.schedule_id_seq'::regclass);


--
-- Name: screen id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen ALTER COLUMN id SET DEFAULT nextval('t_iuri.screen_id_seq'::regclass);


--
-- Name: screen_command id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_command ALTER COLUMN id SET DEFAULT nextval('t_iuri.screen_command_id_seq'::regclass);


--
-- Name: screen_group id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_group ALTER COLUMN id SET DEFAULT nextval('t_iuri.screen_group_id_seq'::regclass);


--
-- Name: screen_media id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_media ALTER COLUMN id SET DEFAULT nextval('t_iuri.screen_media_id_seq'::regclass);


--
-- Name: screen_snapshot id; Type: DEFAULT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_snapshot ALTER COLUMN id SET DEFAULT nextval('t_iuri.screen_snapshot_id_seq'::regclass);


--
-- Data for Name: demo_lead; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.demo_lead (id, session_id, kind, value, created_at) FROM stdin;
\.


--
-- Data for Name: demo_login_token; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.demo_login_token (token_hash, session_id, role, username, reusable, expires_at, used_at) FROM stdin;
\.


--
-- Data for Name: demo_sandbox; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.demo_sandbox (tenant_id, kind, seeded_at, assigned_at, created_at) FROM stdin;
\.


--
-- Data for Name: demo_session; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.demo_session (id, tenant_id, slug, origin, prospect_name, ip_hash, lead_kind, lead_value, extendable, created_at, expires_at, extended_at, ended_at, end_reason) FROM stdin;
\.


--
-- Data for Name: demo_settings; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.demo_settings (id, enabled, duration_minutes, extension_enabled, extension_minutes, pool_size, rate_limit_per_ip_per_hour, max_live_sandboxes, lead_enabled, cta_enabled, cta_label, cta_url, welcome_intro_enabled, welcome_intro, owner_validity_hours, upload_limit_enabled, upload_limit_kb, updated_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
0	\N	<< Flyway Schema Creation >>	SCHEMA	"platform"	\N	app_advertisement	2026-11-06 00:52:06.625404	0	t
1	1	platform schema	SQL	V1__platform_schema.sql	-862493218	app_advertisement	2026-11-06 00:52:06.698367	112	t
2	2	google login ticket	SQL	V2__google_login_ticket.sql	1851962423	app_advertisement	2026-11-06 00:52:06.878052	33	t
3	3	demo	SQL	V3__demo.sql	-1131760166	app_advertisement	2026-11-06 00:52:06.941174	72	t
4	4	turnstile settings	SQL	V4__turnstile_settings.sql	579410678	app_advertisement	2026-11-06 00:52:07.040874	20	t
\.


--
-- Data for Name: google_login_ticket; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.google_login_ticket (ticket_hash, tenant_slug, binding_hash, sub, email, name, picture, expires_at) FROM stdin;
\.


--
-- Data for Name: tenant; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.tenant (id, slug, schema_name, name, status, central_customer_id, central_subscription_id, plan_code, admin_email, admin_provisioned_at, trial_ends_at, current_period_end, suspended_at, delete_after, entitlements_json, entitlements_etag, entitlements_fetched_at, created_at, updated_at) FROM stdin;
1	exemplo	t_exemplo	Telas Exemplo	active	\N	\N	\N	gloomysoftware@gmail.com	2026-11-06 00:57:16.625516+00	\N	\N	\N	\N	\N	\N	\N	2026-11-06 00:57:12.062522+00	2026-11-06 00:57:16.626901+00
2	iuri	t_iuri	Telas do Iuri	active	\N	\N	\N	gloomysoftware@gmail.com	2026-11-06 21:27:13.687605+00	\N	\N	\N	\N	\N	\N	\N	2026-11-06 21:27:07.798907+00	2026-11-06 21:27:13.68897+00
\.


--
-- Data for Name: tenant_domain; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.tenant_domain (id, tenant_id, host, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_event; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.tenant_event (event_id, type, payload, status, attempts, last_error, received_at, last_attempt_at, processed_at) FROM stdin;
\.


--
-- Data for Name: tenant_host_cert; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.tenant_host_cert (id, tenant_id, host, custom, status, requested_at, ready_at) FROM stdin;
\.


--
-- Data for Name: turnstile_settings; Type: TABLE DATA; Schema: platform; Owner: app_advertisement
--

COPY platform.turnstile_settings (id, enabled, site_key, secret_key, extra_paths_enabled, extra_paths, updated_at) FROM stdin;
\.


--
-- Data for Name: app_setting; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.app_setting (id, offline_after_seconds, heartbeat_seconds, history_retention_enabled, history_retention_days, updated_at, auto_send_enabled, live_preview_enabled, live_preview_seconds, periodic_snapshot_enabled, periodic_snapshot_minutes) FROM stdin;
1	90	30	t	90	2026-11-06 00:57:12.54215+00	f	t	5	f	15
\.


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.app_user (id, name, email, password_hash, role, active, password_defined, created_at, updated_at) FROM stdin;
1	Administrador	gloomysoftware@gmail.com	$2b$10$3u/cpIZiJ1x16ccDaCRone7X.wdxDMcSFFKmWre1F5sZ7AutmEd42	ADMIN	t	t	2026-11-06 00:57:12.678611+00	2026-11-06 00:57:12.678611+00
\.


--
-- Data for Name: delivery; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.delivery (id, fk_id_screen, revision, manifest, media_ids, status, bytes_done, bytes_total, current_media, failure_reason, fk_id_sentby, created_at, started_at, finished_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
0	\N	<< Flyway Schema Creation >>	SCHEMA	"t_exemplo"	\N	app_advertisement	2026-11-06 00:57:12.173373	0	t
1	1	screen management	SQL	V1__screen_management.sql	-1655513423	app_advertisement	2026-11-06 00:57:12.198355	152	t
2	2	playlists from screens and remote control	SQL	V2__playlists_from_screens_and_remote_control.sql	780048657	app_advertisement	2026-11-06 22:30:48.233861	43	t
3	3	app update channel	SQL	V3__app_update_channel.sql	-1633969859	app_advertisement	2026-11-06 23:41:40.858054	24	t
4	4	playlist origin	SQL	V4__playlist_origin.sql	749420132	app_advertisement	2026-11-07 00:54:20.951731	84	t
5	5	screen live preview	SQL	V5__screen_live_preview.sql	-2090213146	app_advertisement	2026-11-08 01:39:43.835272	69	t
6	6	instants with time zone	SQL	V6__instants_with_time_zone.sql	1772364392	app_advertisement	2026-11-08 02:47:46.192244	130	t
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.media (id, name, kind, mime_type, size_bytes, sha256, duration_seconds, width, height, stored_file, poster_file, fk_id_createdby, created_at) FROM stdin;
\.


--
-- Data for Name: media_upload; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.media_upload (id, upload_key, name, mime_type, size_bytes, received_bytes, fk_id_createdby, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_token; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.password_token (id, fk_id_user, token_hash, purpose, expires_at, used_at, created_at) FROM stdin;
1	1	0218a4de23fed54d12af91ec613c81bc60f07486fad805808bd093dd4f4a55e7	SET_PASSWORD	2026-11-08 00:57:12.682617+00	\N	2026-11-06 00:57:12.683385+00
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.playlist (id, name, interval_seconds, items, created_at, updated_at, mini, rotation_epoch, fk_id_originscreen, origin_local_id, imported_at, edited_since_import) FROM stdin;
\.


--
-- Data for Name: schedule; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.schedule (id, name, fk_id_playlist, days_of_week, start_time, end_time, priority, enabled, created_at, updated_at, fk_id_originscreen, origin_local_id) FROM stdin;
\.


--
-- Data for Name: screen; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.screen (id, name, fk_id_group, token_hash, device_id, platform, app_version, orientation, resolution, last_seen_at, now_playing, disk_free_bytes, disk_total_bytes, own_programming, fk_id_defaultplaylist, schedule_ids, fk_id_currentdelivery, applied_revision, inventory_reported_at, created_at, updated_at, local_content, local_content_at, attention_until, latest_app_version, edition, preview_until) FROM stdin;
\.


--
-- Data for Name: screen_command; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.screen_command (id, fk_id_screen, type, argument, status, result_message, fk_id_createdby, created_at, finished_at, duration_minutes, result_ref) FROM stdin;
\.


--
-- Data for Name: screen_group; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.screen_group (id, name, fk_id_defaultplaylist, schedule_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: screen_media; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.screen_media (id, fk_id_screen, local_id, media_id, name, size_bytes, in_use, from_server) FROM stdin;
\.


--
-- Data for Name: screen_snapshot; Type: TABLE DATA; Schema: t_exemplo; Owner: app_advertisement
--

COPY t_exemplo.screen_snapshot (id, fk_id_screen, image, size_bytes, media_local_id, captured_at) FROM stdin;
\.


--
-- Data for Name: app_setting; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.app_setting (id, offline_after_seconds, heartbeat_seconds, history_retention_enabled, history_retention_days, updated_at, auto_send_enabled, live_preview_enabled, live_preview_seconds, periodic_snapshot_enabled, periodic_snapshot_minutes) FROM stdin;
1	90	30	t	90	2026-11-06 22:42:37.753935+00	f	t	5	f	15
\.


--
-- Data for Name: app_user; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.app_user (id, name, email, password_hash, role, active, password_defined, created_at, updated_at) FROM stdin;
1	Iuri	gloomysoftware@gmail.com	$2b$10$tlg6/YHgHuEK18LmH7V4ouSAh6Wn14AIsBvtJy0HUYK1.5DtPBfHa	ADMIN	t	t	2026-11-06 21:27:08.732618+00	2026-11-06 21:27:39.418167+00
\.


--
-- Data for Name: delivery; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.delivery (id, fk_id_screen, revision, manifest, media_ids, status, bytes_done, bytes_total, current_media, failure_reason, fk_id_sentby, created_at, started_at, finished_at, updated_at) FROM stdin;
8	2	fb9656667d9c0d88c3557707d477cb8d5632dd7042b7bb36a03fac40b35d224e	{"media": [{"id": "srv-9", "kind": "IMAGE", "name": "image.png", "width": 454, "height": 681, "sha256": "d621bbb2e322d3fa2b6405d34d67d93e9262e9f27652622026e07680a46be732", "mimeType": "image/png", "serverId": 9, "sizeBytes": 69463, "durationSeconds": 10}, {"id": "srv-10", "kind": "IMAGE", "name": "WhatsApp Image 2026-10-05 at 11.24.51.jpeg", "width": 960, "height": 1280, "sha256": "9d01f6d0e057e2416284b55f0d1c76a7b5fb9d9399d0e6befbe5d6d555cebfc0", "mimeType": "image/jpeg", "serverId": 10, "sizeBytes": 113685, "durationSeconds": 10}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}], "playlists": [{"id": "srv-p5", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "muie", "items": [{"id": "srv-p5-55b6ca6a-db20-414f-a981-d70527a24f62", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-9", "sources": [{"id": "srv-p5-770787f6-b553-4c11-be0d-1efea0f95305", "kind": "MEDIA", "mediaId": "srv-9", "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 10}, {"id": "srv-p5-feca8470-30f0-445c-ad23-05216ca8c830", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-10", "sources": [{"id": "srv-p5-40e92b4b-f461-42b5-9ef9-700b9cb06661", "kind": "MEDIA", "mediaId": "srv-10", "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 10}, {"id": "srv-p5-e3", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-11", "sources": [{"id": "srv-p5-e3-s1", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}], "intervalSeconds": 3}], "schedules": [], "defaultPlaylistId": "srv-p5"}	[9, 10, 11]	APPLIED	4139314	4139314	\N	\N	1	2026-11-07 00:40:14.757974+00	\N	2026-11-07 00:40:17.321407+00	2026-11-07 00:40:17.322575+00
2	2	06febaf8e73948b43ee4e0f35ace989e98227cb128b8882c2d7e3ac45488cf44	{"media": [{"id": "srv-5", "kind": "IMAGE", "name": "Logo LAILA Imóveis em Fundo Escuro.png", "width": 1536, "height": 1024, "sha256": "c63584e2c99d46f53b4c9001ef22dadf2d28a3cd7469c4c2c0709eab6efda514", "mimeType": "image/png", "serverId": 5, "sizeBytes": 1244896, "durationSeconds": 10}], "playlists": [{"id": "srv-p2", "name": "Teste", "items": [{"id": "srv-p2-e1", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-5", "sources": [{"id": "srv-p2-e1-s1", "kind": "MEDIA", "mediaId": "srv-5", "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 10}], "intervalSeconds": 0}], "schedules": [], "defaultPlaylistId": "srv-p2"}	[5]	SUPERSEDED	1244896	1244896	\N	\N	1	2026-11-06 21:58:10.136934+00	\N	2026-11-07 00:40:10.731869+00	2026-11-07 00:40:10.753436+00
7	2	f256833c042410751fb04fe0d1e5a24cb2c2f3b86e2843c98087922b8c24c9b5	{"media": [{"id": "srv-9", "kind": "IMAGE", "name": "image.png", "width": 454, "height": 681, "sha256": "d621bbb2e322d3fa2b6405d34d67d93e9262e9f27652622026e07680a46be732", "mimeType": "image/png", "serverId": 9, "sizeBytes": 69463, "durationSeconds": 10}, {"id": "srv-10", "kind": "IMAGE", "name": "WhatsApp Image 2026-10-05 at 11.24.51.jpeg", "width": 960, "height": 1280, "sha256": "9d01f6d0e057e2416284b55f0d1c76a7b5fb9d9399d0e6befbe5d6d555cebfc0", "mimeType": "image/jpeg", "serverId": 10, "sizeBytes": 113685, "durationSeconds": 10}], "playlists": [{"id": "srv-p6", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "muie", "items": [{"id": "srv-p6-55b6ca6a-db20-414f-a981-d70527a24f62", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-9", "sources": [{"id": "srv-p6-770787f6-b553-4c11-be0d-1efea0f95305", "kind": "MEDIA", "mediaId": "srv-9", "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 10}, {"id": "srv-p6-feca8470-30f0-445c-ad23-05216ca8c830", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-10", "sources": [{"id": "srv-p6-40e92b4b-f461-42b5-9ef9-700b9cb06661", "kind": "MEDIA", "mediaId": "srv-10", "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 10}], "intervalSeconds": 3}], "schedules": [], "defaultPlaylistId": "srv-p6"}	[9, 10]	SUPERSEDED	183148	183148	\N	\N	1	2026-11-07 00:40:10.737565+00	\N	2026-11-07 00:40:14.754943+00	2026-11-07 00:40:14.7599+00
9	6	2748afdc391813ef42bd310586f94fd5c9fb92d5c1946527b25cbd4a054a7bdf	{"media": [{"id": "srv-12", "kind": "VIDEO", "name": "C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4", "width": 1280, "height": 720, "sha256": "e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503", "mimeType": "video/mp4", "serverId": 12, "sizeBytes": 56894823, "durationSeconds": 29}, {"id": "srv-13", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.34.mp4", "width": 1920, "height": 960, "sha256": "210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7", "mimeType": "video/mp4", "serverId": 13, "sizeBytes": 2114773, "durationSeconds": 15}, {"id": "srv-14", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.35.mp4", "width": 1920, "height": 960, "sha256": "bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352", "mimeType": "video/mp4", "serverId": 14, "sizeBytes": 6359746, "durationSeconds": 15}, {"id": "srv-15", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.07.mp4", "width": 1920, "height": 960, "sha256": "e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674", "mimeType": "video/mp4", "serverId": 15, "sizeBytes": 8590823, "durationSeconds": 15}, {"id": "srv-16", "kind": "VIDEO", "name": "Balioni engenharia.mp4", "width": 3840, "height": 1920, "sha256": "af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7", "mimeType": "video/mp4", "serverId": 16, "sizeBytes": 25881828, "durationSeconds": 15}, {"id": "srv-17", "kind": "VIDEO", "name": "IMG_4623.MP4", "width": 2036, "height": 1018, "sha256": "6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29", "mimeType": "video/mp4", "serverId": 17, "sizeBytes": 8253832, "durationSeconds": 15}, {"id": "srv-18", "kind": "VIDEO", "name": "eletroclima.mp4", "width": 1920, "height": 960, "sha256": "c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5", "mimeType": "video/mp4", "serverId": 18, "sizeBytes": 2327936, "durationSeconds": 15}, {"id": "srv-19", "kind": "VIDEO", "name": "BARBOTERAPIA - TELÃO FOMINHA (1).mp4", "width": 1920, "height": 1080, "sha256": "808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8", "mimeType": "video/mp4", "serverId": 19, "sizeBytes": 16841682, "durationSeconds": 15}, {"id": "srv-20", "kind": "IMAGE", "name": "WhatsApp Image 2026-08-20 at 21.45.33.jpeg", "width": 1600, "height": 800, "sha256": "2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4", "mimeType": "image/jpeg", "serverId": 20, "sizeBytes": 294175, "durationSeconds": 10}, {"id": "srv-21", "kind": "VIDEO", "name": "Vitória (1).mp4", "width": 3840, "height": 2160, "sha256": "8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad", "mimeType": "video/mp4", "serverId": 21, "sizeBytes": 12735695, "durationSeconds": 16}, {"id": "srv-22", "kind": "VIDEO", "name": "Arthur.mp4", "width": 3840, "height": 2160, "sha256": "2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8", "mimeType": "video/mp4", "serverId": 22, "sizeBytes": 11125312, "durationSeconds": 14}, {"id": "srv-23", "kind": "VIDEO", "name": "WhatsApp Video 2026-09-02 at 22.42.39.mp4", "width": 1920, "height": 960, "sha256": "ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f", "mimeType": "video/mp4", "serverId": 23, "sizeBytes": 4343391, "durationSeconds": 15}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}], "playlists": [{"id": "srv-p7", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "fominha", "items": [{"id": "srv-p7-f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-12", "sources": [{"id": "srv-p7-cbf5363a-0af7-45a1-b208-d00f8347c891", "kind": "MEDIA", "mediaId": "srv-12", "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 29}, {"id": "srv-p7-0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-13", "sources": [{"id": "srv-p7-2337ba1c-fd34-41a2-82c3-3b7f773afef8", "kind": "MEDIA", "mediaId": "srv-13", "durationSeconds": 15}, {"id": "srv-p7-8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "kind": "MEDIA", "mediaId": "srv-14", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-15", "sources": [{"id": "srv-p7-16e3791e-691e-4d57-870d-fe42aa5a3f58", "kind": "MEDIA", "mediaId": "srv-15", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-16", "sources": [{"id": "srv-p7-4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "kind": "MEDIA", "mediaId": "srv-16", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-17", "sources": [{"id": "srv-p7-b7f9afe1-1683-42a7-ba33-470ddfb34a84", "kind": "MEDIA", "mediaId": "srv-17", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-18", "sources": [{"id": "srv-p7-00aefeb0-16a7-4473-8344-8f325a5ea492", "kind": "MEDIA", "mediaId": "srv-18", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-19", "sources": [{"id": "srv-p7-7b45cd98-d019-4fb3-93e6-d4964d812a42", "kind": "MEDIA", "mediaId": "srv-19", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-20", "sources": [{"id": "srv-p7-716f1c9a-fde4-4ece-88f4-2eff06c8166f", "kind": "MEDIA", "mediaId": "srv-20", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-21", "sources": [{"id": "srv-p7-3956382f-dfb5-44de-a74e-c4a9f053dc73", "kind": "MEDIA", "mediaId": "srv-21", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-22", "sources": [{"id": "srv-p7-82f94201-1db6-460a-97b2-9333abb88f58", "kind": "MEDIA", "mediaId": "srv-22", "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 14}, {"id": "srv-p7-858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-23", "sources": [{"id": "srv-p7-e5e40e2e-369a-4707-b699-ef68bb42e101", "kind": "MEDIA", "mediaId": "srv-23", "durationSeconds": 15}, {"id": "srv-p7-22dc0c67-c48c-456a-80cb-44621eca0d18", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}], "intervalSeconds": 22}], "schedules": [], "defaultPlaylistId": "srv-p7"}	[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 11]	SUPERSEDED	159720182	159720182	\N	\N	\N	2026-11-07 02:59:27.829287+00	2026-11-07 02:59:31.082951+00	2026-11-07 04:01:42.993745+00	2026-11-07 04:01:42.998197+00
10	6	12bcfa18c01d0afd11e03e00282d9b353758c023d11ef04d1bca9396b5becdea	{"media": [{"id": "srv-12", "kind": "VIDEO", "name": "C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4", "width": 1280, "height": 720, "sha256": "e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503", "mimeType": "video/mp4", "serverId": 12, "sizeBytes": 56894823, "durationSeconds": 29}, {"id": "srv-13", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.34.mp4", "width": 1920, "height": 960, "sha256": "210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7", "mimeType": "video/mp4", "serverId": 13, "sizeBytes": 2114773, "durationSeconds": 15}, {"id": "srv-14", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.35.mp4", "width": 1920, "height": 960, "sha256": "bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352", "mimeType": "video/mp4", "serverId": 14, "sizeBytes": 6359746, "durationSeconds": 15}, {"id": "srv-15", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.07.mp4", "width": 1920, "height": 960, "sha256": "e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674", "mimeType": "video/mp4", "serverId": 15, "sizeBytes": 8590823, "durationSeconds": 15}, {"id": "srv-16", "kind": "VIDEO", "name": "Balioni engenharia.mp4", "width": 3840, "height": 1920, "sha256": "af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7", "mimeType": "video/mp4", "serverId": 16, "sizeBytes": 25881828, "durationSeconds": 15}, {"id": "srv-17", "kind": "VIDEO", "name": "IMG_4623.MP4", "width": 2036, "height": 1018, "sha256": "6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29", "mimeType": "video/mp4", "serverId": 17, "sizeBytes": 8253832, "durationSeconds": 15}, {"id": "srv-18", "kind": "VIDEO", "name": "eletroclima.mp4", "width": 1920, "height": 960, "sha256": "c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5", "mimeType": "video/mp4", "serverId": 18, "sizeBytes": 2327936, "durationSeconds": 15}, {"id": "srv-19", "kind": "VIDEO", "name": "BARBOTERAPIA - TELÃO FOMINHA (1).mp4", "width": 1920, "height": 1080, "sha256": "808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8", "mimeType": "video/mp4", "serverId": 19, "sizeBytes": 16841682, "durationSeconds": 15}, {"id": "srv-20", "kind": "IMAGE", "name": "WhatsApp Image 2026-08-20 at 21.45.33.jpeg", "width": 1600, "height": 800, "sha256": "2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4", "mimeType": "image/jpeg", "serverId": 20, "sizeBytes": 294175, "durationSeconds": 10}, {"id": "srv-21", "kind": "VIDEO", "name": "Vitória (1).mp4", "width": 3840, "height": 2160, "sha256": "8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad", "mimeType": "video/mp4", "serverId": 21, "sizeBytes": 12735695, "durationSeconds": 16}, {"id": "srv-22", "kind": "VIDEO", "name": "Arthur.mp4", "width": 3840, "height": 2160, "sha256": "2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8", "mimeType": "video/mp4", "serverId": 22, "sizeBytes": 11125312, "durationSeconds": 14}, {"id": "srv-23", "kind": "VIDEO", "name": "WhatsApp Video 2026-09-02 at 22.42.39.mp4", "width": 1920, "height": 960, "sha256": "ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f", "mimeType": "video/mp4", "serverId": 23, "sizeBytes": 4343391, "durationSeconds": 15}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}, {"id": "srv-24", "kind": "VIDEO", "name": "anuncie-aqui-15s.mp4", "width": 1920, "height": 960, "sha256": "caf0f3f40973ddbf139c4bc63d32ac7aed07a3d5aff2bcb5e5e4c5d03f4a9b8e", "mimeType": "video/mp4", "serverId": 24, "sizeBytes": 3172751, "durationSeconds": 15}], "playlists": [{"id": "srv-p7", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "fominha", "items": [{"id": "srv-p7-f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-12", "sources": [{"id": "srv-p7-cbf5363a-0af7-45a1-b208-d00f8347c891", "kind": "MEDIA", "mediaId": "srv-12", "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 29}, {"id": "srv-p7-0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-13", "sources": [{"id": "srv-p7-2337ba1c-fd34-41a2-82c3-3b7f773afef8", "kind": "MEDIA", "mediaId": "srv-13", "durationSeconds": 15}, {"id": "srv-p7-8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "kind": "MEDIA", "mediaId": "srv-14", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-15", "sources": [{"id": "srv-p7-16e3791e-691e-4d57-870d-fe42aa5a3f58", "kind": "MEDIA", "mediaId": "srv-15", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-16", "sources": [{"id": "srv-p7-4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "kind": "MEDIA", "mediaId": "srv-16", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-17", "sources": [{"id": "srv-p7-b7f9afe1-1683-42a7-ba33-470ddfb34a84", "kind": "MEDIA", "mediaId": "srv-17", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-18", "sources": [{"id": "srv-p7-00aefeb0-16a7-4473-8344-8f325a5ea492", "kind": "MEDIA", "mediaId": "srv-18", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-19", "sources": [{"id": "srv-p7-7b45cd98-d019-4fb3-93e6-d4964d812a42", "kind": "MEDIA", "mediaId": "srv-19", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-20", "sources": [{"id": "srv-p7-716f1c9a-fde4-4ece-88f4-2eff06c8166f", "kind": "MEDIA", "mediaId": "srv-20", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-21", "sources": [{"id": "srv-p7-3956382f-dfb5-44de-a74e-c4a9f053dc73", "kind": "MEDIA", "mediaId": "srv-21", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-22", "sources": [{"id": "srv-p7-82f94201-1db6-460a-97b2-9333abb88f58", "kind": "MEDIA", "mediaId": "srv-22", "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 14}, {"id": "srv-p7-858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-23", "sources": [{"id": "srv-p7-e5e40e2e-369a-4707-b699-ef68bb42e101", "kind": "MEDIA", "mediaId": "srv-23", "durationSeconds": 15}, {"id": "srv-p7-22dc0c67-c48c-456a-80cb-44621eca0d18", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e12", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-24", "sources": [{"id": "srv-p7-e12-s1", "kind": "MEDIA", "mediaId": "srv-24", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}], "intervalSeconds": 22}], "schedules": [], "defaultPlaylistId": "srv-p7"}	[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 11, 24]	SUPERSEDED	162892933	162892933	\N	\N	1	2026-11-07 04:01:42.995659+00	2026-11-07 04:02:06.357671+00	2026-11-09 21:55:30.991516+00	2026-11-09 21:55:31.035136+00
12	6	7081fe30679eb0e08d7cbbe02992f393bf8021ae84461c17b2147970d2c47753	{"media": [{"id": "srv-12", "kind": "VIDEO", "name": "C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4", "width": 1280, "height": 720, "sha256": "e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503", "mimeType": "video/mp4", "serverId": 12, "sizeBytes": 56894823, "durationSeconds": 29}, {"id": "srv-13", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.34.mp4", "width": 1920, "height": 960, "sha256": "210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7", "mimeType": "video/mp4", "serverId": 13, "sizeBytes": 2114773, "durationSeconds": 15}, {"id": "srv-14", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.35.mp4", "width": 1920, "height": 960, "sha256": "bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352", "mimeType": "video/mp4", "serverId": 14, "sizeBytes": 6359746, "durationSeconds": 15}, {"id": "srv-15", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.07.mp4", "width": 1920, "height": 960, "sha256": "e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674", "mimeType": "video/mp4", "serverId": 15, "sizeBytes": 8590823, "durationSeconds": 15}, {"id": "srv-16", "kind": "VIDEO", "name": "Balioni engenharia.mp4", "width": 3840, "height": 1920, "sha256": "af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7", "mimeType": "video/mp4", "serverId": 16, "sizeBytes": 25881828, "durationSeconds": 15}, {"id": "srv-17", "kind": "VIDEO", "name": "IMG_4623.MP4", "width": 2036, "height": 1018, "sha256": "6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29", "mimeType": "video/mp4", "serverId": 17, "sizeBytes": 8253832, "durationSeconds": 15}, {"id": "srv-18", "kind": "VIDEO", "name": "eletroclima.mp4", "width": 1920, "height": 960, "sha256": "c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5", "mimeType": "video/mp4", "serverId": 18, "sizeBytes": 2327936, "durationSeconds": 15}, {"id": "srv-19", "kind": "VIDEO", "name": "BARBOTERAPIA - TELÃO FOMINHA (1).mp4", "width": 1920, "height": 1080, "sha256": "808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8", "mimeType": "video/mp4", "serverId": 19, "sizeBytes": 16841682, "durationSeconds": 15}, {"id": "srv-20", "kind": "IMAGE", "name": "WhatsApp Image 2026-08-20 at 21.45.33.jpeg", "width": 1600, "height": 800, "sha256": "2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4", "mimeType": "image/jpeg", "serverId": 20, "sizeBytes": 294175, "durationSeconds": 10}, {"id": "srv-21", "kind": "VIDEO", "name": "Vitória (1).mp4", "width": 3840, "height": 2160, "sha256": "8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad", "mimeType": "video/mp4", "serverId": 21, "sizeBytes": 12735695, "durationSeconds": 16}, {"id": "srv-22", "kind": "VIDEO", "name": "Arthur.mp4", "width": 3840, "height": 2160, "sha256": "2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8", "mimeType": "video/mp4", "serverId": 22, "sizeBytes": 11125312, "durationSeconds": 14}, {"id": "srv-23", "kind": "VIDEO", "name": "WhatsApp Video 2026-09-02 at 22.42.39.mp4", "width": 1920, "height": 960, "sha256": "ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f", "mimeType": "video/mp4", "serverId": 23, "sizeBytes": 4343391, "durationSeconds": 15}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}, {"id": "srv-24", "kind": "VIDEO", "name": "anuncie-aqui-15s.mp4", "width": 1920, "height": 960, "sha256": "caf0f3f40973ddbf139c4bc63d32ac7aed07a3d5aff2bcb5e5e4c5d03f4a9b8e", "mimeType": "video/mp4", "serverId": 24, "sizeBytes": 3172751, "durationSeconds": 15}, {"id": "srv-25", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.03.30.mp4", "width": 1920, "height": 960, "sha256": "867d9947d2392fb693f72d026f1689d9c589e86055bd1e29f90365d1d1384fbf", "mimeType": "video/mp4", "serverId": 25, "sizeBytes": 3147537, "durationSeconds": 15}, {"id": "srv-26", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.04.06.mp4", "width": 1920, "height": 960, "sha256": "d4800d5be38c78f0403c8c3453d48c1e9f4755b3913a0c331162b9373a54f876", "mimeType": "video/mp4", "serverId": 26, "sizeBytes": 3929978, "durationSeconds": 15}, {"id": "srv-27", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-10 at 21.58.49.mp4", "width": 1024, "height": 576, "sha256": "c5a5f7d6e95fb2e36e4a8a697af263db10e982fe935d07a03d8437f0807e952b", "mimeType": "video/mp4", "serverId": 27, "sizeBytes": 2448832, "durationSeconds": 15}], "playlists": [{"id": "srv-p7", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "fominha", "items": [{"id": "srv-p7-f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-12", "sources": [{"id": "srv-p7-cbf5363a-0af7-45a1-b208-d00f8347c891", "kind": "MEDIA", "mediaId": "srv-12", "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 29}, {"id": "srv-p7-0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-13", "sources": [{"id": "srv-p7-2337ba1c-fd34-41a2-82c3-3b7f773afef8", "kind": "MEDIA", "mediaId": "srv-13", "durationSeconds": 15}, {"id": "srv-p7-8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "kind": "MEDIA", "mediaId": "srv-14", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-15", "sources": [{"id": "srv-p7-16e3791e-691e-4d57-870d-fe42aa5a3f58", "kind": "MEDIA", "mediaId": "srv-15", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-16", "sources": [{"id": "srv-p7-4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "kind": "MEDIA", "mediaId": "srv-16", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-17", "sources": [{"id": "srv-p7-b7f9afe1-1683-42a7-ba33-470ddfb34a84", "kind": "MEDIA", "mediaId": "srv-17", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-18", "sources": [{"id": "srv-p7-00aefeb0-16a7-4473-8344-8f325a5ea492", "kind": "MEDIA", "mediaId": "srv-18", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-19", "sources": [{"id": "srv-p7-7b45cd98-d019-4fb3-93e6-d4964d812a42", "kind": "MEDIA", "mediaId": "srv-19", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-20", "sources": [{"id": "srv-p7-716f1c9a-fde4-4ece-88f4-2eff06c8166f", "kind": "MEDIA", "mediaId": "srv-20", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-21", "sources": [{"id": "srv-p7-3956382f-dfb5-44de-a74e-c4a9f053dc73", "kind": "MEDIA", "mediaId": "srv-21", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-22", "sources": [{"id": "srv-p7-82f94201-1db6-460a-97b2-9333abb88f58", "kind": "MEDIA", "mediaId": "srv-22", "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 14}, {"id": "srv-p7-858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-23", "sources": [{"id": "srv-p7-e5e40e2e-369a-4707-b699-ef68bb42e101", "kind": "MEDIA", "mediaId": "srv-23", "durationSeconds": 15}, {"id": "srv-p7-22dc0c67-c48c-456a-80cb-44621eca0d18", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e12", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-24", "sources": [{"id": "srv-p7-e12-s1", "kind": "MEDIA", "mediaId": "srv-24", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e13", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-25", "sources": [{"id": "srv-p7-e13-s1", "kind": "MEDIA", "mediaId": "srv-25", "durationSeconds": 15}, {"id": "srv-p7-e13-s2", "kind": "MEDIA", "mediaId": "srv-26", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e14", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-27", "sources": [{"id": "srv-p7-e14-s1", "kind": "MEDIA", "mediaId": "srv-27", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}], "intervalSeconds": 22}], "schedules": [], "defaultPlaylistId": "srv-p7"}	[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 11, 24, 25, 26, 27]	SUPERSEDED	172419280	172419280	\N	\N	1	2026-11-11 01:16:58.42675+00	\N	2026-11-11 21:57:49.43613+00	2026-11-11 21:57:49.602863+00
11	6	9a576bf99b9ff9c7a30308517718ff6214d399a7fbf3e077969e6d0044f297e6	{"media": [{"id": "srv-12", "kind": "VIDEO", "name": "C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4", "width": 1280, "height": 720, "sha256": "e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503", "mimeType": "video/mp4", "serverId": 12, "sizeBytes": 56894823, "durationSeconds": 29}, {"id": "srv-13", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.34.mp4", "width": 1920, "height": 960, "sha256": "210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7", "mimeType": "video/mp4", "serverId": 13, "sizeBytes": 2114773, "durationSeconds": 15}, {"id": "srv-14", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.35.mp4", "width": 1920, "height": 960, "sha256": "bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352", "mimeType": "video/mp4", "serverId": 14, "sizeBytes": 6359746, "durationSeconds": 15}, {"id": "srv-15", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.07.mp4", "width": 1920, "height": 960, "sha256": "e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674", "mimeType": "video/mp4", "serverId": 15, "sizeBytes": 8590823, "durationSeconds": 15}, {"id": "srv-16", "kind": "VIDEO", "name": "Balioni engenharia.mp4", "width": 3840, "height": 1920, "sha256": "af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7", "mimeType": "video/mp4", "serverId": 16, "sizeBytes": 25881828, "durationSeconds": 15}, {"id": "srv-17", "kind": "VIDEO", "name": "IMG_4623.MP4", "width": 2036, "height": 1018, "sha256": "6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29", "mimeType": "video/mp4", "serverId": 17, "sizeBytes": 8253832, "durationSeconds": 15}, {"id": "srv-18", "kind": "VIDEO", "name": "eletroclima.mp4", "width": 1920, "height": 960, "sha256": "c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5", "mimeType": "video/mp4", "serverId": 18, "sizeBytes": 2327936, "durationSeconds": 15}, {"id": "srv-19", "kind": "VIDEO", "name": "BARBOTERAPIA - TELÃO FOMINHA (1).mp4", "width": 1920, "height": 1080, "sha256": "808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8", "mimeType": "video/mp4", "serverId": 19, "sizeBytes": 16841682, "durationSeconds": 15}, {"id": "srv-20", "kind": "IMAGE", "name": "WhatsApp Image 2026-08-20 at 21.45.33.jpeg", "width": 1600, "height": 800, "sha256": "2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4", "mimeType": "image/jpeg", "serverId": 20, "sizeBytes": 294175, "durationSeconds": 10}, {"id": "srv-21", "kind": "VIDEO", "name": "Vitória (1).mp4", "width": 3840, "height": 2160, "sha256": "8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad", "mimeType": "video/mp4", "serverId": 21, "sizeBytes": 12735695, "durationSeconds": 16}, {"id": "srv-22", "kind": "VIDEO", "name": "Arthur.mp4", "width": 3840, "height": 2160, "sha256": "2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8", "mimeType": "video/mp4", "serverId": 22, "sizeBytes": 11125312, "durationSeconds": 14}, {"id": "srv-23", "kind": "VIDEO", "name": "WhatsApp Video 2026-09-02 at 22.42.39.mp4", "width": 1920, "height": 960, "sha256": "ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f", "mimeType": "video/mp4", "serverId": 23, "sizeBytes": 4343391, "durationSeconds": 15}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}, {"id": "srv-24", "kind": "VIDEO", "name": "anuncie-aqui-15s.mp4", "width": 1920, "height": 960, "sha256": "caf0f3f40973ddbf139c4bc63d32ac7aed07a3d5aff2bcb5e5e4c5d03f4a9b8e", "mimeType": "video/mp4", "serverId": 24, "sizeBytes": 3172751, "durationSeconds": 15}, {"id": "srv-25", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.03.30.mp4", "width": 1920, "height": 960, "sha256": "867d9947d2392fb693f72d026f1689d9c589e86055bd1e29f90365d1d1384fbf", "mimeType": "video/mp4", "serverId": 25, "sizeBytes": 3147537, "durationSeconds": 15}, {"id": "srv-26", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.04.06.mp4", "width": 1920, "height": 960, "sha256": "d4800d5be38c78f0403c8c3453d48c1e9f4755b3913a0c331162b9373a54f876", "mimeType": "video/mp4", "serverId": 26, "sizeBytes": 3929978, "durationSeconds": 15}], "playlists": [{"id": "srv-p7", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "fominha", "items": [{"id": "srv-p7-f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-12", "sources": [{"id": "srv-p7-cbf5363a-0af7-45a1-b208-d00f8347c891", "kind": "MEDIA", "mediaId": "srv-12", "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 29}, {"id": "srv-p7-0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-13", "sources": [{"id": "srv-p7-2337ba1c-fd34-41a2-82c3-3b7f773afef8", "kind": "MEDIA", "mediaId": "srv-13", "durationSeconds": 15}, {"id": "srv-p7-8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "kind": "MEDIA", "mediaId": "srv-14", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-15", "sources": [{"id": "srv-p7-16e3791e-691e-4d57-870d-fe42aa5a3f58", "kind": "MEDIA", "mediaId": "srv-15", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-16", "sources": [{"id": "srv-p7-4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "kind": "MEDIA", "mediaId": "srv-16", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-17", "sources": [{"id": "srv-p7-b7f9afe1-1683-42a7-ba33-470ddfb34a84", "kind": "MEDIA", "mediaId": "srv-17", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-18", "sources": [{"id": "srv-p7-00aefeb0-16a7-4473-8344-8f325a5ea492", "kind": "MEDIA", "mediaId": "srv-18", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-19", "sources": [{"id": "srv-p7-7b45cd98-d019-4fb3-93e6-d4964d812a42", "kind": "MEDIA", "mediaId": "srv-19", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-20", "sources": [{"id": "srv-p7-716f1c9a-fde4-4ece-88f4-2eff06c8166f", "kind": "MEDIA", "mediaId": "srv-20", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-21", "sources": [{"id": "srv-p7-3956382f-dfb5-44de-a74e-c4a9f053dc73", "kind": "MEDIA", "mediaId": "srv-21", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-22", "sources": [{"id": "srv-p7-82f94201-1db6-460a-97b2-9333abb88f58", "kind": "MEDIA", "mediaId": "srv-22", "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 14}, {"id": "srv-p7-858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-23", "sources": [{"id": "srv-p7-e5e40e2e-369a-4707-b699-ef68bb42e101", "kind": "MEDIA", "mediaId": "srv-23", "durationSeconds": 15}, {"id": "srv-p7-22dc0c67-c48c-456a-80cb-44621eca0d18", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e12", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-24", "sources": [{"id": "srv-p7-e12-s1", "kind": "MEDIA", "mediaId": "srv-24", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e13", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-25", "sources": [{"id": "srv-p7-e13-s1", "kind": "MEDIA", "mediaId": "srv-25", "durationSeconds": 15}, {"id": "srv-p7-e13-s2", "kind": "MEDIA", "mediaId": "srv-26", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}], "intervalSeconds": 22}], "schedules": [], "defaultPlaylistId": "srv-p7"}	[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 11, 24, 25, 26]	SUPERSEDED	169970448	169970448	\N	\N	1	2026-11-09 21:55:31.011173+00	\N	2026-11-11 01:16:58.416712+00	2026-11-11 01:16:58.45045+00
13	6	8a68cb5e53ba9496133f36e3f93702e6d698076bd89c39b3733dafab400a39bb	{"media": [{"id": "srv-12", "kind": "VIDEO", "name": "C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4", "width": 1280, "height": 720, "sha256": "e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503", "mimeType": "video/mp4", "serverId": 12, "sizeBytes": 56894823, "durationSeconds": 29}, {"id": "srv-13", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.34.mp4", "width": 1920, "height": 960, "sha256": "210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7", "mimeType": "video/mp4", "serverId": 13, "sizeBytes": 2114773, "durationSeconds": 15}, {"id": "srv-14", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.35.mp4", "width": 1920, "height": 960, "sha256": "bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352", "mimeType": "video/mp4", "serverId": 14, "sizeBytes": 6359746, "durationSeconds": 15}, {"id": "srv-15", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-05 at 22.48.07.mp4", "width": 1920, "height": 960, "sha256": "e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674", "mimeType": "video/mp4", "serverId": 15, "sizeBytes": 8590823, "durationSeconds": 15}, {"id": "srv-16", "kind": "VIDEO", "name": "Balioni engenharia.mp4", "width": 3840, "height": 1920, "sha256": "af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7", "mimeType": "video/mp4", "serverId": 16, "sizeBytes": 25881828, "durationSeconds": 15}, {"id": "srv-17", "kind": "VIDEO", "name": "IMG_4623.MP4", "width": 2036, "height": 1018, "sha256": "6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29", "mimeType": "video/mp4", "serverId": 17, "sizeBytes": 8253832, "durationSeconds": 15}, {"id": "srv-18", "kind": "VIDEO", "name": "eletroclima.mp4", "width": 1920, "height": 960, "sha256": "c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5", "mimeType": "video/mp4", "serverId": 18, "sizeBytes": 2327936, "durationSeconds": 15}, {"id": "srv-19", "kind": "VIDEO", "name": "BARBOTERAPIA - TELÃO FOMINHA (1).mp4", "width": 1920, "height": 1080, "sha256": "808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8", "mimeType": "video/mp4", "serverId": 19, "sizeBytes": 16841682, "durationSeconds": 15}, {"id": "srv-20", "kind": "IMAGE", "name": "WhatsApp Image 2026-08-20 at 21.45.33.jpeg", "width": 1600, "height": 800, "sha256": "2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4", "mimeType": "image/jpeg", "serverId": 20, "sizeBytes": 294175, "durationSeconds": 10}, {"id": "srv-21", "kind": "VIDEO", "name": "Vitória (1).mp4", "width": 3840, "height": 2160, "sha256": "8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad", "mimeType": "video/mp4", "serverId": 21, "sizeBytes": 12735695, "durationSeconds": 16}, {"id": "srv-22", "kind": "VIDEO", "name": "Arthur.mp4", "width": 3840, "height": 2160, "sha256": "2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8", "mimeType": "video/mp4", "serverId": 22, "sizeBytes": 11125312, "durationSeconds": 14}, {"id": "srv-23", "kind": "VIDEO", "name": "WhatsApp Video 2026-09-02 at 22.42.39.mp4", "width": 1920, "height": 960, "sha256": "ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f", "mimeType": "video/mp4", "serverId": 23, "sizeBytes": 4343391, "durationSeconds": 15}, {"id": "srv-11", "kind": "VIDEO", "name": "black-15s.mp4", "width": 1920, "height": 960, "sha256": "922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e", "mimeType": "video/mp4", "serverId": 11, "sizeBytes": 3956166, "durationSeconds": 15}, {"id": "srv-24", "kind": "VIDEO", "name": "anuncie-aqui-15s.mp4", "width": 1920, "height": 960, "sha256": "caf0f3f40973ddbf139c4bc63d32ac7aed07a3d5aff2bcb5e5e4c5d03f4a9b8e", "mimeType": "video/mp4", "serverId": 24, "sizeBytes": 3172751, "durationSeconds": 15}, {"id": "srv-25", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.03.30.mp4", "width": 1920, "height": 960, "sha256": "867d9947d2392fb693f72d026f1689d9c589e86055bd1e29f90365d1d1384fbf", "mimeType": "video/mp4", "serverId": 25, "sizeBytes": 3147537, "durationSeconds": 15}, {"id": "srv-26", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-09 at 12.04.06.mp4", "width": 1920, "height": 960, "sha256": "d4800d5be38c78f0403c8c3453d48c1e9f4755b3913a0c331162b9373a54f876", "mimeType": "video/mp4", "serverId": 26, "sizeBytes": 3929978, "durationSeconds": 15}, {"id": "srv-27", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-10 at 21.58.49.mp4", "width": 1024, "height": 576, "sha256": "c5a5f7d6e95fb2e36e4a8a697af263db10e982fe935d07a03d8437f0807e952b", "mimeType": "video/mp4", "serverId": 27, "sizeBytes": 2448832, "durationSeconds": 15}, {"id": "srv-28", "kind": "VIDEO", "name": "apresentacao-v5-15s.mp4", "width": 1920, "height": 960, "sha256": "4da8344ea9c7f8bf3fddcb3e3178b6d7c35920013a74c3cfbf02e62271e77144", "mimeType": "video/mp4", "serverId": 28, "sizeBytes": 2598271, "durationSeconds": 15}, {"id": "srv-31", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-11 at 14.51.23 (1).mp4", "width": 1920, "height": 960, "sha256": "19a802b90331b66938876e92a4360e1ebd367402a57af9a9c6fc1845934b1354", "mimeType": "video/mp4", "serverId": 31, "sizeBytes": 851633, "durationSeconds": 15}, {"id": "srv-29", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-11 at 14.51.23.mp4", "width": 1920, "height": 960, "sha256": "484329d3342e7e716044f06952e59b7c305ea4804595c35faf511373306bd960", "mimeType": "video/mp4", "serverId": 29, "sizeBytes": 660243, "durationSeconds": 15}, {"id": "srv-30", "kind": "VIDEO", "name": "WhatsApp Video 2026-11-11 at 14.51.24.mp4", "width": 1920, "height": 960, "sha256": "df3776cec9033bb0c655ddcb869cbaf95236a2379407502c2ac34ae97719338a", "mimeType": "video/mp4", "serverId": 30, "sizeBytes": 798377, "durationSeconds": 15}], "playlists": [{"id": "srv-p7", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "fominha", "items": [{"id": "srv-p7-f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-12", "sources": [{"id": "srv-p7-cbf5363a-0af7-45a1-b208-d00f8347c891", "kind": "MEDIA", "mediaId": "srv-12", "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 29}, {"id": "srv-p7-0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-13", "sources": [{"id": "srv-p7-2337ba1c-fd34-41a2-82c3-3b7f773afef8", "kind": "MEDIA", "mediaId": "srv-13", "durationSeconds": 15}, {"id": "srv-p7-8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "kind": "MEDIA", "mediaId": "srv-14", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-15", "sources": [{"id": "srv-p7-16e3791e-691e-4d57-870d-fe42aa5a3f58", "kind": "MEDIA", "mediaId": "srv-15", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-16", "sources": [{"id": "srv-p7-4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "kind": "MEDIA", "mediaId": "srv-16", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-17", "sources": [{"id": "srv-p7-b7f9afe1-1683-42a7-ba33-470ddfb34a84", "kind": "MEDIA", "mediaId": "srv-17", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-18", "sources": [{"id": "srv-p7-00aefeb0-16a7-4473-8344-8f325a5ea492", "kind": "MEDIA", "mediaId": "srv-18", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-19", "sources": [{"id": "srv-p7-7b45cd98-d019-4fb3-93e6-d4964d812a42", "kind": "MEDIA", "mediaId": "srv-19", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-20", "sources": [{"id": "srv-p7-716f1c9a-fde4-4ece-88f4-2eff06c8166f", "kind": "MEDIA", "mediaId": "srv-20", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-21", "sources": [{"id": "srv-p7-3956382f-dfb5-44de-a74e-c4a9f053dc73", "kind": "MEDIA", "mediaId": "srv-21", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-22", "sources": [{"id": "srv-p7-82f94201-1db6-460a-97b2-9333abb88f58", "kind": "MEDIA", "mediaId": "srv-22", "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 14}, {"id": "srv-p7-858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-23", "sources": [{"id": "srv-p7-e5e40e2e-369a-4707-b699-ef68bb42e101", "kind": "MEDIA", "mediaId": "srv-23", "durationSeconds": 15}, {"id": "srv-p7-22dc0c67-c48c-456a-80cb-44621eca0d18", "kind": "MEDIA", "mediaId": "srv-11", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e12", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-24", "sources": [{"id": "srv-p7-e12-s1", "kind": "MEDIA", "mediaId": "srv-24", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e13", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-25", "sources": [{"id": "srv-p7-e13-s1", "kind": "MEDIA", "mediaId": "srv-25", "durationSeconds": 15}, {"id": "srv-p7-e13-s2", "kind": "MEDIA", "mediaId": "srv-26", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e14", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-27", "sources": [{"id": "srv-p7-e14-s1", "kind": "MEDIA", "mediaId": "srv-27", "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 16}, {"id": "srv-p7-e15", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-28", "sources": [{"id": "srv-p7-e15-s1", "kind": "MEDIA", "mediaId": "srv-28", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}, {"id": "srv-p7-e16", "fit": "contain", "kind": "MEDIA", "label": null, "mediaId": "srv-31", "sources": [{"id": "srv-p7-e16-s1", "kind": "MEDIA", "mediaId": "srv-31", "durationSeconds": 15}, {"id": "srv-p7-e16-s2", "kind": "MEDIA", "mediaId": "srv-29", "durationSeconds": 15}, {"id": "srv-p7-e16-s3", "kind": "MEDIA", "mediaId": "srv-30", "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN", "durationSeconds": 15}], "intervalSeconds": 22}], "schedules": [], "defaultPlaylistId": "srv-p7"}	[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 11, 24, 25, 26, 27, 28, 31, 29, 30]	APPLIED	177327804	177327804	\N	\N	1	2026-11-11 21:57:49.494022+00	2026-11-11 21:57:59.455897+00	2026-11-11 21:58:02.525962+00	2026-11-11 21:58:02.526203+00
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
0	\N	<< Flyway Schema Creation >>	SCHEMA	"t_iuri"	\N	app_advertisement	2026-11-06 21:27:08.025101	0	t
1	1	screen management	SQL	V1__screen_management.sql	-1655513423	app_advertisement	2026-11-06 21:27:08.106738	132	t
2	2	playlists from screens and remote control	SQL	V2__playlists_from_screens_and_remote_control.sql	780048657	app_advertisement	2026-11-06 22:30:48.45405	16	t
3	3	app update channel	SQL	V3__app_update_channel.sql	-1633969859	app_advertisement	2026-11-06 23:41:41.018176	9	t
4	4	playlist origin	SQL	V4__playlist_origin.sql	749420132	app_advertisement	2026-11-07 00:54:21.19711	40	t
5	5	screen live preview	SQL	V5__screen_live_preview.sql	-2090213146	app_advertisement	2026-11-08 01:39:44.139069	22	t
6	6	instants with time zone	SQL	V6__instants_with_time_zone.sql	1772364392	app_advertisement	2026-11-08 02:47:46.480258	106	t
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.media (id, name, kind, mime_type, size_bytes, sha256, duration_seconds, width, height, stored_file, poster_file, fk_id_createdby, created_at) FROM stdin;
2	image (7).png	IMAGE	image/png	47911	80477a9fec8d693d900c245b074f45f712f506630f2c4bb907574ec2db232875	10	276	150	44b4af09-1ec6-4ee5-9528-3b9b8ac1defd	a3180d3e-4237-4042-939b-2bfcce068354.jpg	1	2026-11-06 21:57:25.338076+00
3	image (5).png	IMAGE	image/png	32205	68a67820b953a4a4402cb4fd3e1c64f5670ae24da1526959514c5ab1dff0452b	10	271	103	ec12d63b-8689-49f6-ad5e-7cd75a9d28cb	2600ecec-ef7d-4406-9554-52f3f072db89.jpg	1	2026-11-06 21:57:25.339801+00
4	image (8).png	IMAGE	image/png	37034	0e59cbe992640bbc9d4299271cd191ac245f617996e82f54b2e62adf5c600b41	10	290	96	deeef930-506f-4a19-919d-1287bc7c7409	f454745b-8d8c-4ec5-af4b-abdbec42ba0b.jpg	1	2026-11-06 21:57:25.354264+00
5	Logo LAILA Imóveis em Fundo Escuro.png	IMAGE	image/png	1244896	c63584e2c99d46f53b4c9001ef22dadf2d28a3cd7469c4c2c0709eab6efda514	10	1536	1024	5a81224b-616b-4305-be7d-f20440fa355d	d5dc38d2-67e7-4d84-87ff-27cec58fa72a.jpg	1	2026-11-06 21:57:25.536652+00
9	image.png	IMAGE	image/png	69463	d621bbb2e322d3fa2b6405d34d67d93e9262e9f27652622026e07680a46be732	10	454	681	37a965d2-bbea-4915-8062-089524de5624	\N	\N	2026-11-07 00:35:58.591481+00
10	WhatsApp Image 2026-10-05 at 11.24.51.jpeg	IMAGE	image/jpeg	113685	9d01f6d0e057e2416284b55f0d1c76a7b5fb9d9399d0e6befbe5d6d555cebfc0	10	960	1280	664d6970-179e-457f-9ee1-0ae85956e366	\N	\N	2026-11-07 00:35:58.721982+00
11	black-15s.mp4	VIDEO	video/mp4	3956166	922c189bce4292133db5d4a5ec472c2376ae14411685f4d797236197d23f6b3e	15	1920	960	d8b8a283-dd89-46a3-a666-a430b1ab8e8a	4de45f0d-c9c6-4079-8527-04a867d64103.jpg	1	2026-11-07 00:39:49.226796+00
12	C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4	VIDEO	video/mp4	56894823	e942b682fe1c373022cdb203ce4f019c881db535d03c5a056ac4c49ed8776503	29	1280	720	710e0b40-92cf-465e-9c31-825608a9cbee	90a129d1-650c-4e67-911e-bc34ae5be318.jpg	\N	2026-11-07 02:56:50.748838+00
13	WhatsApp Video 2026-11-05 at 22.48.34.mp4	VIDEO	video/mp4	2114773	210ce19d36c9ed8e5e4f6d65767f337a14332d18762229c130a93c78c98c80c7	15	1920	960	3c55c0f0-697e-4c3b-94f2-ddf93f6d050a	7f28e25d-50ea-4e75-b8c8-da9e6a1ef05e.jpg	\N	2026-11-07 02:56:55.542207+00
14	WhatsApp Video 2026-11-05 at 22.48.35.mp4	VIDEO	video/mp4	6359746	bb98d0bac24313f897e5f72c8793d9b49e7b3501020f547f1da026c228403352	15	1920	960	41747c46-e7f1-4262-b717-f63a7884143a	b7f63e4d-55fd-4390-a762-3ecb4ff1b371.jpg	\N	2026-11-07 02:57:05.294632+00
15	WhatsApp Video 2026-11-05 at 22.48.07.mp4	VIDEO	video/mp4	8590823	e24ae63b1e540de375948ad584cc7b158fbe69e4dc3957e641c668a2d1e32674	15	1920	960	fa99c771-defd-49b9-92de-035369a10bc5	0e8603fb-d3af-42ae-a911-7ed2e5260318.jpg	\N	2026-11-07 02:57:19.028953+00
16	Balioni engenharia.mp4	VIDEO	video/mp4	25881828	af0d519347173f9482ee134ddba4e152380b3028d7b87a528e42e4c66548fde7	15	3840	1920	1bdb3b04-77df-4739-b202-5a52ca9aad05	cee71d8f-1b69-48ee-839a-79ea14b741d3.jpg	\N	2026-11-07 02:57:59.174291+00
17	IMG_4623.MP4	VIDEO	video/mp4	8253832	6677b780ea6b0e984119d03fa93568430a6e1ed7f04ae38dc98b7cd311661b29	15	2036	1018	defc0660-799c-44e5-8c7f-f6db89aad8ec	a315718c-1ddc-498c-be2f-9fda26841dff.jpg	\N	2026-11-07 02:58:18.129147+00
18	eletroclima.mp4	VIDEO	video/mp4	2327936	c1df17f553b40ed1e2be58edfd8bc5842ce25e523e1546433df845f1b7c6a9e5	15	1920	960	e110f917-b0b1-45e3-ad40-fbe97c5d2fbe	edcd301f-4cd0-415b-9083-a375315f984b.jpg	\N	2026-11-07 02:58:23.311587+00
19	BARBOTERAPIA - TELÃO FOMINHA (1).mp4	VIDEO	video/mp4	16841682	808f809dd4d278a34313a58d6180f38c5c2d29a1d93ebed66a7ca2e7a49b6ca8	15	1920	1080	1d8b3247-b83d-4ded-8a38-4ce38539477a	4d3374ec-9ef0-40b8-aab5-fcb4d4036448.jpg	\N	2026-11-07 02:58:48.267556+00
20	WhatsApp Image 2026-08-20 at 21.45.33.jpeg	IMAGE	image/jpeg	294175	2baff5f202bb151a2905db65237abf50f4fc3f3a8a22422d0bcb58c6f4cbe6d4	10	1600	800	5b9a655d-db17-4f50-8218-1521173a59b6	\N	\N	2026-11-07 02:58:48.663155+00
21	Vitória (1).mp4	VIDEO	video/mp4	12735695	8716c47b41fda48e6d84afa9e05d1b28eb2b7090796808a2b12a0fde216fd5ad	16	3840	2160	f50cdeb5-160b-452c-b786-88c2f635dc81	4be156fc-5a6d-4e6f-a1b0-358c84ac5025.jpg	\N	2026-11-07 02:59:06.733868+00
22	Arthur.mp4	VIDEO	video/mp4	11125312	2273762e690f100c91770a22d5b8ac1280f25d37b0560cb9bb86b25e9b2233e8	14	3840	2160	712027d2-c97b-420f-84ad-cbcd476ec46d	b1f37ae8-6671-48e3-b04b-378525626830.jpg	\N	2026-11-07 02:59:21.122063+00
23	WhatsApp Video 2026-09-02 at 22.42.39.mp4	VIDEO	video/mp4	4343391	ccb1ae3160a19c4eb9ae84671af2023fe3b05e2049d5e93ac5e2eb8a648d6b0f	15	1920	960	fb680195-9a07-452b-b7ac-ddbba1b79d55	db6f10ea-db98-4059-9e4c-4859934e7806.jpg	\N	2026-11-07 02:59:27.561984+00
24	anuncie-aqui-15s.mp4	VIDEO	video/mp4	3172751	caf0f3f40973ddbf139c4bc63d32ac7aed07a3d5aff2bcb5e5e4c5d03f4a9b8e	15	1920	960	ea0b64fd-b14b-4228-8032-e94e594a45f4	e1ec9272-7068-4db6-a56e-8f6f40498bbd.jpg	1	2026-11-07 04:00:20.428171+00
25	WhatsApp Video 2026-11-09 at 12.03.30.mp4	VIDEO	video/mp4	3147537	867d9947d2392fb693f72d026f1689d9c589e86055bd1e29f90365d1d1384fbf	15	1920	960	6d30d366-6938-49a4-9db8-31ca1307db73	ac810a20-6287-4623-836e-84aae47fabba.jpg	1	2026-11-09 21:54:26.528878+00
26	WhatsApp Video 2026-11-09 at 12.04.06.mp4	VIDEO	video/mp4	3929978	d4800d5be38c78f0403c8c3453d48c1e9f4755b3913a0c331162b9373a54f876	15	1920	960	63dea92f-7ef3-43a8-adaf-7bf4146a7929	eefba738-d85e-499d-80a7-fd8dec9fd50f.jpg	1	2026-11-09 21:54:26.980296+00
27	WhatsApp Video 2026-11-10 at 21.58.49.mp4	VIDEO	video/mp4	2448832	c5a5f7d6e95fb2e36e4a8a697af263db10e982fe935d07a03d8437f0807e952b	15	1024	576	9902f1f7-eef4-4ddc-b8de-95a10f2d4a6e	e9de1316-4d8d-4d66-bcb8-a7da41b2fcd2.jpg	1	2026-11-11 00:59:25.51346+00
28	apresentacao-v5-15s.mp4	VIDEO	video/mp4	2598271	4da8344ea9c7f8bf3fddcb3e3178b6d7c35920013a74c3cfbf02e62271e77144	15	1920	960	20aba61c-4207-41ad-8787-c89e556f0c24	108da25a-6257-4d4c-bd82-e2cd875c8aaa.jpg	1	2026-11-11 17:49:49.149369+00
29	WhatsApp Video 2026-11-11 at 14.51.23.mp4	VIDEO	video/mp4	660243	484329d3342e7e716044f06952e59b7c305ea4804595c35faf511373306bd960	15	1920	960	7f5f3304-04d9-48a4-b4c8-899af51258fc	f774040c-22cd-4bfc-8950-13aced041e82.jpg	1	2026-11-11 17:52:27.963169+00
30	WhatsApp Video 2026-11-11 at 14.51.24.mp4	VIDEO	video/mp4	798377	df3776cec9033bb0c655ddcb869cbaf95236a2379407502c2ac34ae97719338a	15	1920	960	6f746cb6-0739-4e68-8a04-4ded436c098a	4c696723-9f9a-42ef-adfd-66d7199a2547.jpg	1	2026-11-11 17:52:28.205298+00
31	WhatsApp Video 2026-11-11 at 14.51.23 (1).mp4	VIDEO	video/mp4	851633	19a802b90331b66938876e92a4360e1ebd367402a57af9a9c6fc1845934b1354	15	1920	960	6685ba0b-4fbc-45bd-a709-dbe598c6d6fa	c3bcd6fb-2d10-401c-a4cc-837ab0d35445.jpg	1	2026-11-11 17:52:28.250101+00
\.


--
-- Data for Name: media_upload; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.media_upload (id, upload_key, name, mime_type, size_bytes, received_bytes, fk_id_createdby, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_token; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.password_token (id, fk_id_user, token_hash, purpose, expires_at, used_at, created_at) FROM stdin;
1	1	0d102d16164d90080235bb87165fbe6242cb79db374c0d0b0d7fcc9c1609979a	SET_PASSWORD	2026-11-08 21:27:08.738823+00	\N	2026-11-06 21:27:08.740043+00
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.playlist (id, name, interval_seconds, items, created_at, updated_at, mini, rotation_epoch, fk_id_originscreen, origin_local_id, imported_at, edited_since_import) FROM stdin;
2	Teste	0	[{"id": "e1", "fit": "contain", "label": null, "sources": [{"id": "e1-s1", "mediaId": 5, "joinPrevious": false, "durationSeconds": 10}], "rotation": 0, "background": "BLACK"}]	2026-11-06 21:57:52.506653+00	2026-11-06 21:57:52.506653+00	\N	0	\N	\N	\N	f
5	muie	3	[{"id": "55b6ca6a-db20-414f-a981-d70527a24f62", "fit": "contain", "label": null, "sources": [{"id": "770787f6-b553-4c11-be0d-1efea0f95305", "mediaId": 9, "joinPrevious": false, "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "feca8470-30f0-445c-ad23-05216ca8c830", "fit": "contain", "label": null, "sources": [{"id": "40e92b4b-f461-42b5-9ef9-700b9cb06661", "mediaId": 10, "joinPrevious": false, "durationSeconds": 10}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e3", "fit": "contain", "label": null, "sources": [{"id": "e3-s1", "mediaId": 11, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}]	2026-11-07 00:35:58.784847+00	2026-11-07 00:39:55.66132+00	{"height": 250, "margin": 16, "placement": "topRight"}	0	2	02c926a7-0219-422a-ac69-a11a238fd7bb	2026-11-07 00:35:58.784847+00	t
7	fominha	22	[{"id": "f5ed41d1-0434-443a-87de-5209a39a7715", "fit": "contain", "label": null, "sources": [{"id": "cbf5363a-0af7-45a1-b208-d00f8347c891", "mediaId": 12, "joinPrevious": false, "durationSeconds": 29}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "0c01dd7f-3b33-4cf4-8184-b3c33cd801d5", "fit": "contain", "label": null, "sources": [{"id": "2337ba1c-fd34-41a2-82c3-3b7f773afef8", "mediaId": 13, "joinPrevious": false, "durationSeconds": 15}, {"id": "8dabad93-9995-4d5f-9f09-a98dbbc2aee5", "mediaId": 14, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "31f0fba3-7721-4daa-8b27-039e619be4fc", "fit": "contain", "label": null, "sources": [{"id": "16e3791e-691e-4d57-870d-fe42aa5a3f58", "mediaId": 15, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "ec09be11-ef89-4d4a-b818-c0c6a09af956", "fit": "contain", "label": null, "sources": [{"id": "4b1ab69b-5573-4fb6-aca3-bd80a36ee0e9", "mediaId": 16, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "8f4dabb8-5a05-4760-ae61-a43f0068c728", "fit": "contain", "label": null, "sources": [{"id": "b7f9afe1-1683-42a7-ba33-470ddfb34a84", "mediaId": 17, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "dac1b7ac-e0de-48db-8fcd-f90c05fdb55b", "fit": "contain", "label": null, "sources": [{"id": "00aefeb0-16a7-4473-8344-8f325a5ea492", "mediaId": 18, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "3f6ac628-a52a-4817-a8e2-9a6a59b3732a", "fit": "contain", "label": null, "sources": [{"id": "7b45cd98-d019-4fb3-93e6-d4964d812a42", "mediaId": 19, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "d8d419ad-9027-4c7d-9f21-c25bf3c11911", "fit": "contain", "label": null, "sources": [{"id": "716f1c9a-fde4-4ece-88f4-2eff06c8166f", "mediaId": 20, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "5e926246-dac0-4bb5-96f4-ed0fb05d56b2", "fit": "contain", "label": null, "sources": [{"id": "3956382f-dfb5-44de-a74e-c4a9f053dc73", "mediaId": 21, "joinPrevious": false, "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "04b41ea6-e65e-4111-a91c-7ebb5aaca444", "fit": "contain", "label": null, "sources": [{"id": "82f94201-1db6-460a-97b2-9333abb88f58", "mediaId": 22, "joinPrevious": false, "durationSeconds": 14}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "858f4d7a-f963-42ad-839f-d0895b804cbb", "fit": "contain", "label": null, "sources": [{"id": "e5e40e2e-369a-4707-b699-ef68bb42e101", "mediaId": 23, "joinPrevious": false, "durationSeconds": 15}, {"id": "22dc0c67-c48c-456a-80cb-44621eca0d18", "mediaId": 11, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e12", "fit": "contain", "label": null, "sources": [{"id": "e12-s1", "mediaId": 24, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e13", "fit": "contain", "label": null, "sources": [{"id": "e13-s1", "mediaId": 25, "joinPrevious": false, "durationSeconds": 15}, {"id": "e13-s2", "mediaId": 26, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e14", "fit": "contain", "label": null, "sources": [{"id": "e14-s1", "mediaId": 27, "joinPrevious": false, "durationSeconds": 16}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e15", "fit": "contain", "label": null, "sources": [{"id": "e15-s1", "mediaId": 28, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}, {"id": "e16", "fit": "contain", "label": null, "sources": [{"id": "e16-s1", "mediaId": 31, "joinPrevious": false, "durationSeconds": 15}, {"id": "e16-s2", "mediaId": 29, "joinPrevious": false, "durationSeconds": 15}, {"id": "e16-s3", "mediaId": 30, "joinPrevious": false, "durationSeconds": 15}], "rotation": 0, "background": "BLACK", "displayMode": "FULLSCREEN"}]	2026-11-07 02:59:27.809176+00	2026-11-11 17:53:11.156071+00	{"height": 250, "margin": 16, "placement": "topRight"}	0	6	e4d19e76-cf42-4fcd-8324-6bda4bff45cc	2026-11-07 02:59:27.808525+00	t
\.


--
-- Data for Name: schedule; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.schedule (id, name, fk_id_playlist, days_of_week, start_time, end_time, priority, enabled, created_at, updated_at, fk_id_originscreen, origin_local_id) FROM stdin;
\.


--
-- Data for Name: screen; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.screen (id, name, fk_id_group, token_hash, device_id, platform, app_version, orientation, resolution, last_seen_at, now_playing, disk_free_bytes, disk_total_bytes, own_programming, fk_id_defaultplaylist, schedule_ids, fk_id_currentdelivery, applied_revision, inventory_reported_at, created_at, updated_at, local_content, local_content_at, attention_until, latest_app_version, edition, preview_until) FROM stdin;
2	DESKTOP-62C8TBI	\N	4becb61f2061046d58546c4d173e93df62a2279be057db1462541e005e884b6b	ad378443db43d8d7370e915d80c55462	WINDOWS	0.3.2	0	\N	2026-11-13 15:07:48.113613+00	{"paused": false, "stopped": true, "itemLabel": null, "mediaName": null, "positionMs": null, "mediaLocalId": null, "playlistName": null, "overrideUntil": null, "overridePlaylistName": null}	16932065280	253175525376	t	5	[]	8	fb9656667d9c0d88c3557707d477cb8d5632dd7042b7bb36a03fac40b35d224e	2026-11-12 16:01:57.962989+00	2026-11-06 21:55:19.536945+00	2026-11-13 15:07:48.114477+00	{"media": [], "playlists": [{"id": "p-padrao", "mini": {"height": 250, "margin": 16, "placement": "topRight"}, "name": "Padrão", "items": [{"id": "pi-bra", "fit": "contain", "kind": "INFO", "sources": [{"id": "pi-bra-src", "kind": "INFO", "infoSourceId": "s-sports-bra", "durationSeconds": 20}], "background": "BLACK", "displayMode": "FULLSCREEN", "infoSourceId": "s-sports-bra", "durationSeconds": 20}, {"id": "pi-clima", "fit": "contain", "kind": "INFO", "sources": [{"id": "pi-clima-src", "kind": "INFO", "infoSourceId": "s-weather-sp", "durationSeconds": 15}], "background": "BLACK", "displayMode": "FULLSCREEN", "infoSourceId": "s-weather-sp", "durationSeconds": 15}], "createdAt": "2026-11-06T21:54:59.282Z", "updatedAt": "2026-11-06T21:54:59.282Z", "intervalSeconds": 3}], "schedules": [], "defaultPlaylistId": null}	2026-11-12 16:01:57.963232+00	2026-11-07 04:06:07.075952+00	0.3.2	OWNER	\N
6	Fominha Ituiutaba	\N	5328eebbd25756eb6ec12e2691407b8fbd19211525c44304a7928e52fb211896	0e5f5f4bdc1b074666768ed9cb3d13b1	WINDOWS	0.3.2	0	\N	2026-11-14 05:02:18.044735+00	{"paused": false, "stopped": true, "itemLabel": null, "mediaName": null, "positionMs": null, "mediaLocalId": null, "playlistName": null, "overrideUntil": null, "overridePlaylistName": "fominha"}	63869587456	119326392320	t	7	[]	13	8a68cb5e53ba9496133f36e3f93702e6d698076bd89c39b3733dafab400a39bb	2026-11-14 03:57:31.117215+00	2026-11-07 02:55:01.382739+00	2026-11-14 05:02:18.047618+00	{"media": [], "playlists": [], "schedules": [], "defaultPlaylistId": null}	2026-11-14 03:57:31.117566+00	2026-11-12 02:07:12.74931+00	0.3.2	OWNER	2026-11-12 02:05:31.815499+00
\.


--
-- Data for Name: screen_command; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.screen_command (id, fk_id_screen, type, argument, status, result_message, fk_id_createdby, created_at, finished_at, duration_minutes, result_ref) FROM stdin;
15	2	IMPORT_PLAYLIST	02c926a7-0219-422a-ac69-a11a238fd7bb	DONE	Trazida para o painel como muie.	1	2026-11-07 00:35:56.63582+00	2026-11-07 00:35:58.799459+00	\N	5
16	2	IMPORT_PLAYLIST	02c926a7-0219-422a-ac69-a11a238fd7bb	DONE	Trazida para o painel como muie.	1	2026-11-07 00:36:04.875981+00	2026-11-07 00:36:05.167812+00	\N	6
17	2	REPORT_INVENTORY	\N	DONE	Lista enviada	1	2026-11-07 00:36:40.501012+00	2026-11-07 00:36:42.261758+00	\N	\N
18	2	REPORT_INVENTORY	\N	DONE	Lista enviada	1	2026-11-07 00:36:44.530978+00	2026-11-07 00:36:46.385143+00	\N	\N
21	6	IMPORT_PLAYLIST	e4d19e76-cf42-4fcd-8324-6bda4bff45cc	DONE	Trazida para o painel como fominha.	1	2026-11-07 02:55:14.642841+00	2026-11-07 02:59:27.850822+00	\N	7
22	6	REPORT_INVENTORY	\N	DONE	Lista enviada	1	2026-11-07 03:45:13.130636+00	2026-11-07 03:45:13.823642+00	\N	\N
23	6	PLAY_PLAYLIST	srv-p7	DONE	Tocando fominha até voltar à programação	1	2026-11-08 00:43:01.459985+00	2026-11-08 00:43:02.558011+00	\N	\N
24	6	PLAY_PLAYLIST	srv-p7	DONE	Tocando fominha até voltar à programação	1	2026-11-09 21:56:39.737244+00	2026-11-09 21:56:41.722663+00	\N	\N
25	6	PLAY_PLAYLIST	srv-p7	DONE	Tocando fominha até voltar à programação	1	2026-11-11 01:17:41.086352+00	2026-11-11 01:17:41.813736+00	\N	\N
26	6	NEXT	\N	DONE	Foi para a próxima	1	2026-11-11 01:18:24.47377+00	2026-11-11 01:18:24.770608+00	\N	\N
27	6	NEXT	\N	DONE	Foi para a próxima	1	2026-11-11 01:18:31.800742+00	2026-11-11 01:18:32.969008+00	\N	\N
28	6	PLAY_PLAYLIST	srv-p7	DONE	Tocando fominha até voltar à programação	1	2026-11-11 21:58:12.33859+00	2026-11-11 21:58:13.885837+00	\N	\N
29	6	RESUME_SCHEDULE	\N	DONE	De volta à programação	1	2026-11-11 22:33:08.410416+00	2026-11-11 22:33:10.002623+00	\N	\N
30	6	PLAY_PLAYLIST	srv-p7	DONE	Tocando fominha até voltar à programação	1	2026-11-11 23:53:16.864805+00	2026-11-11 23:53:18.92921+00	\N	\N
\.


--
-- Data for Name: screen_group; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.screen_group (id, name, fk_id_defaultplaylist, schedule_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: screen_media; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.screen_media (id, fk_id_screen, local_id, media_id, name, size_bytes, in_use, from_server) FROM stdin;
694	2	15352b50-8a4a-46f5-a5d9-01334746e899	\N	image.png	69463	f	f
695	2	b79ce85a-3d00-411c-8bfd-20ef4168d083	\N	WhatsApp Image 2026-10-05 at 11.24.51.jpeg	113685	f	f
696	2	srv-10	10	WhatsApp Image 2026-10-05 at 11.24.51.jpeg	113685	t	t
697	2	srv-11	11	black-15s.mp4	3956166	t	t
698	2	srv-5	5	Logo LAILA Imóveis em Fundo Escuro.png	1244896	f	t
699	2	srv-9	9	image.png	69463	t	t
784	6	06199848-977f-44e6-9795-a7096ce5cddf	\N	WhatsApp Image 2026-08-20 at 21.45.33.jpeg	294175	f	f
785	6	1223e5b8-caad-4d69-b8d8-31c4d498a14b	\N	eletroclima.mp4	2327936	f	f
786	6	1edfdafa-17b1-4b7c-805b-1a4102b5aeb5	\N	Arthur.mp4	11125312	f	f
787	6	307386da-2cb0-464a-9bc8-e40dd532d389	\N	BARBOTERAPIA - TELÃO FOMINHA (1).mp4	16841682	f	f
788	6	32d5b2cb-460c-47b8-b344-a26bddd7b970	\N	C__Users_HP_AppData_Roaming_com.lis.advertisement_library_e587efb5-d024-493e-9318-a6f4b5d42f16-IMG_4796.mp4	1023820	f	f
789	6	4e033cca-ca2a-4db6-bde4-545ae0fa6bc1	\N	WhatsApp Video 2026-11-05 at 22.48.07.mp4	8590823	f	f
790	6	57ad24fb-1739-488d-b28f-41badfb5f1f1	\N	96MB Lauren Ferreira Estética.mp4	101294857	f	f
791	6	60ee499d-d0fd-4973-9794-163907402c63	\N	15s.mp4	38008906	f	f
792	6	6cb8ca08-aa64-4ce4-a184-82358de02003	\N	C__Users_HP_AppData_Roaming_com.lis.advertisement_library_083c2390-6cc0-4476-a278-d5da4f611243-pt1.mp4	38914993	f	f
793	6	7657dc08-d495-482b-8e7d-b8bce04450e0	\N	WhatsApp Video 2026-09-02 at 22.42.39.mp4	4343391	f	f
794	6	8913c001-5902-4e7c-83de-9da25ede2a1a	\N	Vitória (1).mp4	12735695	f	f
795	6	98ca68d5-a10e-4d48-b3a1-cbb7359f33c0	\N	IMG_4796.mp4	1023820	f	f
796	6	9d57fe72-2e8e-4fa1-b36c-344c81dc103d	\N	black-15s.mp4	3956166	f	f
797	6	a36e117e-bdce-4ac3-ad22-a66687409acf	\N	WhatsApp Video 2026-11-05 at 22.48.07.mp4	8590823	f	f
798	6	b7b8504a-219d-4ce1-a6f3-f680a3c3cf8a	\N	WhatsApp Video 2026-11-05 at 22.48.35.mp4	6359746	f	f
799	6	baf01f15-3f75-45f3-b39d-cedbeb5d5aab	\N	Balioni engenharia.mp4	25881828	f	f
800	6	cdae11d8-901d-45d1-bed4-072a6a6e2499	\N	C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4	56894823	f	f
801	6	d5a51e1d-8212-42dd-99f3-a8f768b1b4fc	\N	WhatsApp Video 2026-11-05 at 22.48.34.mp4	2114773	f	f
802	6	ed8133e6-fb59-4484-a9bb-de0d86d48655	\N	IMG_4623.MP4	8253832	f	f
803	6	ee4fe1d4-734d-4d02-83c4-0cf90f276b36	\N	WhatsApp Video 2026-09-10 at 17.01.46.mp4	3151404	f	f
804	6	f28eb99d-4bf2-4223-9a10-e43e6d428390	\N	WhatsApp Video 2026-09-02 at 21.45.29.mp4	3694562	f	f
805	6	srv-11	11	black-15s.mp4	3956166	t	t
806	6	srv-12	12	C__Users_HP_AppData_Roaming_com.lis.advertisement_library_0ae3e89b-2059-4cb3-bf8b-3301bd665c8f-parte2.mp4	56894823	t	t
807	6	srv-13	13	WhatsApp Video 2026-11-05 at 22.48.34.mp4	2114773	t	t
808	6	srv-14	14	WhatsApp Video 2026-11-05 at 22.48.35.mp4	6359746	t	t
809	6	srv-15	15	WhatsApp Video 2026-11-05 at 22.48.07.mp4	8590823	t	t
810	6	srv-16	16	Balioni engenharia.mp4	25881828	t	t
811	6	srv-17	17	IMG_4623.MP4	8253832	t	t
812	6	srv-18	18	eletroclima.mp4	2327936	t	t
813	6	srv-19	19	BARBOTERAPIA - TELÃO FOMINHA (1).mp4	16841682	t	t
814	6	srv-20	20	WhatsApp Image 2026-08-20 at 21.45.33.jpeg	294175	t	t
815	6	srv-21	21	Vitória (1).mp4	12735695	t	t
816	6	srv-22	22	Arthur.mp4	11125312	t	t
817	6	srv-23	23	WhatsApp Video 2026-09-02 at 22.42.39.mp4	4343391	t	t
818	6	srv-24	24	anuncie-aqui-15s.mp4	3172751	t	t
819	6	srv-25	25	WhatsApp Video 2026-11-09 at 12.03.30.mp4	3147537	t	t
820	6	srv-26	26	WhatsApp Video 2026-11-09 at 12.04.06.mp4	3929978	t	t
821	6	srv-27	27	WhatsApp Video 2026-11-10 at 21.58.49.mp4	2448832	t	t
822	6	srv-28	28	apresentacao-v5-15s.mp4	2598271	t	t
823	6	srv-29	29	WhatsApp Video 2026-11-11 at 14.51.23.mp4	660243	t	t
824	6	srv-30	30	WhatsApp Video 2026-11-11 at 14.51.24.mp4	798377	t	t
825	6	srv-31	31	WhatsApp Video 2026-11-11 at 14.51.23 (1).mp4	851633	t	t
\.


--
-- Data for Name: screen_snapshot; Type: TABLE DATA; Schema: t_iuri; Owner: app_advertisement
--

COPY t_iuri.screen_snapshot (id, fk_id_screen, image, size_bytes, media_local_id, captured_at) FROM stdin;
\.


--
-- Name: demo_lead_id_seq; Type: SEQUENCE SET; Schema: platform; Owner: app_advertisement
--

SELECT pg_catalog.setval('platform.demo_lead_id_seq', 1, false);


--
-- Name: tenant_domain_id_seq; Type: SEQUENCE SET; Schema: platform; Owner: app_advertisement
--

SELECT pg_catalog.setval('platform.tenant_domain_id_seq', 1, false);


--
-- Name: tenant_host_cert_id_seq; Type: SEQUENCE SET; Schema: platform; Owner: app_advertisement
--

SELECT pg_catalog.setval('platform.tenant_host_cert_id_seq', 1, false);


--
-- Name: tenant_id_seq; Type: SEQUENCE SET; Schema: platform; Owner: app_advertisement
--

SELECT pg_catalog.setval('platform.tenant_id_seq', 2, true);


--
-- Name: app_setting_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.app_setting_id_seq', 1, true);


--
-- Name: app_user_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.app_user_id_seq', 1, true);


--
-- Name: delivery_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.delivery_id_seq', 11, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.media_id_seq', 12, true);


--
-- Name: media_upload_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.media_upload_id_seq', 13, true);


--
-- Name: password_token_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.password_token_id_seq', 1, true);


--
-- Name: playlist_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.playlist_id_seq', 9, true);


--
-- Name: schedule_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.schedule_id_seq', 1, true);


--
-- Name: screen_command_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.screen_command_id_seq', 7, true);


--
-- Name: screen_group_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.screen_group_id_seq', 1, false);


--
-- Name: screen_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.screen_id_seq', 5, true);


--
-- Name: screen_media_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.screen_media_id_seq', 58, true);


--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE SET; Schema: t_exemplo; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_exemplo.screen_snapshot_id_seq', 1, true);


--
-- Name: app_setting_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.app_setting_id_seq', 1, true);


--
-- Name: app_user_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.app_user_id_seq', 1, true);


--
-- Name: delivery_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.delivery_id_seq', 13, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.media_id_seq', 31, true);


--
-- Name: media_upload_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.media_upload_id_seq', 31, true);


--
-- Name: password_token_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.password_token_id_seq', 1, true);


--
-- Name: playlist_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.playlist_id_seq', 7, true);


--
-- Name: schedule_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.schedule_id_seq', 2, true);


--
-- Name: screen_command_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.screen_command_id_seq', 30, true);


--
-- Name: screen_group_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.screen_group_id_seq', 1, false);


--
-- Name: screen_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.screen_id_seq', 6, true);


--
-- Name: screen_media_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.screen_media_id_seq', 825, true);


--
-- Name: screen_snapshot_id_seq; Type: SEQUENCE SET; Schema: t_iuri; Owner: app_advertisement
--

SELECT pg_catalog.setval('t_iuri.screen_snapshot_id_seq', 1, false);


--
-- Name: demo_lead demo_lead_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_lead
    ADD CONSTRAINT demo_lead_pkey PRIMARY KEY (id);


--
-- Name: demo_login_token demo_login_token_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_login_token
    ADD CONSTRAINT demo_login_token_pkey PRIMARY KEY (token_hash);


--
-- Name: demo_sandbox demo_sandbox_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_sandbox
    ADD CONSTRAINT demo_sandbox_pkey PRIMARY KEY (tenant_id);


--
-- Name: demo_session demo_session_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_session
    ADD CONSTRAINT demo_session_pkey PRIMARY KEY (id);


--
-- Name: demo_settings demo_settings_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_settings
    ADD CONSTRAINT demo_settings_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: google_login_ticket google_login_ticket_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.google_login_ticket
    ADD CONSTRAINT google_login_ticket_pkey PRIMARY KEY (ticket_hash);


--
-- Name: tenant_domain tenant_domain_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_domain
    ADD CONSTRAINT tenant_domain_pkey PRIMARY KEY (id);


--
-- Name: tenant_event tenant_event_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_event
    ADD CONSTRAINT tenant_event_pkey PRIMARY KEY (event_id);


--
-- Name: tenant_host_cert tenant_host_cert_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_host_cert
    ADD CONSTRAINT tenant_host_cert_pkey PRIMARY KEY (id);


--
-- Name: tenant tenant_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant
    ADD CONSTRAINT tenant_pkey PRIMARY KEY (id);


--
-- Name: turnstile_settings turnstile_settings_pkey; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.turnstile_settings
    ADD CONSTRAINT turnstile_settings_pkey PRIMARY KEY (id);


--
-- Name: tenant uk_tenant_customer; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant
    ADD CONSTRAINT uk_tenant_customer UNIQUE (central_customer_id);


--
-- Name: tenant_domain uk_tenant_domain_host; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_domain
    ADD CONSTRAINT uk_tenant_domain_host UNIQUE (host);


--
-- Name: tenant_host_cert uk_tenant_host_cert_host; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_host_cert
    ADD CONSTRAINT uk_tenant_host_cert_host UNIQUE (host);


--
-- Name: tenant uk_tenant_schema; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant
    ADD CONSTRAINT uk_tenant_schema UNIQUE (schema_name);


--
-- Name: tenant uk_tenant_slug; Type: CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant
    ADD CONSTRAINT uk_tenant_slug UNIQUE (slug);


--
-- Name: app_setting app_setting_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.app_setting
    ADD CONSTRAINT app_setting_pkey PRIMARY KEY (id);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);


--
-- Name: delivery delivery_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.delivery
    ADD CONSTRAINT delivery_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media_upload media_upload_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media_upload
    ADD CONSTRAINT media_upload_pkey PRIMARY KEY (id);


--
-- Name: password_token password_token_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.password_token
    ADD CONSTRAINT password_token_pkey PRIMARY KEY (id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (id);


--
-- Name: screen_command screen_command_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_command
    ADD CONSTRAINT screen_command_pkey PRIMARY KEY (id);


--
-- Name: screen_group screen_group_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_group
    ADD CONSTRAINT screen_group_pkey PRIMARY KEY (id);


--
-- Name: screen_media screen_media_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_media
    ADD CONSTRAINT screen_media_pkey PRIMARY KEY (id);


--
-- Name: screen screen_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen
    ADD CONSTRAINT screen_pkey PRIMARY KEY (id);


--
-- Name: screen_snapshot screen_snapshot_pkey; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_snapshot
    ADD CONSTRAINT screen_snapshot_pkey PRIMARY KEY (id);


--
-- Name: app_user uk_app_user_email; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.app_user
    ADD CONSTRAINT uk_app_user_email UNIQUE (email);


--
-- Name: media_upload uk_media_upload_key; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media_upload
    ADD CONSTRAINT uk_media_upload_key UNIQUE (upload_key);


--
-- Name: password_token uk_password_token_hash; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.password_token
    ADD CONSTRAINT uk_password_token_hash UNIQUE (token_hash);


--
-- Name: screen uk_screen_token_hash; Type: CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen
    ADD CONSTRAINT uk_screen_token_hash UNIQUE (token_hash);


--
-- Name: app_setting app_setting_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.app_setting
    ADD CONSTRAINT app_setting_pkey PRIMARY KEY (id);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.app_user
    ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);


--
-- Name: delivery delivery_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.delivery
    ADD CONSTRAINT delivery_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media_upload media_upload_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media_upload
    ADD CONSTRAINT media_upload_pkey PRIMARY KEY (id);


--
-- Name: password_token password_token_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.password_token
    ADD CONSTRAINT password_token_pkey PRIMARY KEY (id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (id);


--
-- Name: screen_command screen_command_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_command
    ADD CONSTRAINT screen_command_pkey PRIMARY KEY (id);


--
-- Name: screen_group screen_group_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_group
    ADD CONSTRAINT screen_group_pkey PRIMARY KEY (id);


--
-- Name: screen_media screen_media_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_media
    ADD CONSTRAINT screen_media_pkey PRIMARY KEY (id);


--
-- Name: screen screen_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen
    ADD CONSTRAINT screen_pkey PRIMARY KEY (id);


--
-- Name: screen_snapshot screen_snapshot_pkey; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_snapshot
    ADD CONSTRAINT screen_snapshot_pkey PRIMARY KEY (id);


--
-- Name: app_user uk_app_user_email; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.app_user
    ADD CONSTRAINT uk_app_user_email UNIQUE (email);


--
-- Name: media_upload uk_media_upload_key; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media_upload
    ADD CONSTRAINT uk_media_upload_key UNIQUE (upload_key);


--
-- Name: password_token uk_password_token_hash; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.password_token
    ADD CONSTRAINT uk_password_token_hash UNIQUE (token_hash);


--
-- Name: screen uk_screen_token_hash; Type: CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen
    ADD CONSTRAINT uk_screen_token_hash UNIQUE (token_hash);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX flyway_schema_history_s_idx ON platform.flyway_schema_history USING btree (success);


--
-- Name: idx_demo_login_token_session; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_demo_login_token_session ON platform.demo_login_token USING btree (session_id);


--
-- Name: idx_demo_session_ip; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_demo_session_ip ON platform.demo_session USING btree (ip_hash, created_at);


--
-- Name: idx_demo_session_tenant; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_demo_session_tenant ON platform.demo_session USING btree (tenant_id);


--
-- Name: idx_google_login_ticket_expires; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_google_login_ticket_expires ON platform.google_login_ticket USING btree (expires_at);


--
-- Name: idx_tenant_event_status; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_tenant_event_status ON platform.tenant_event USING btree (status, received_at);


--
-- Name: idx_tenant_host_cert_status; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_tenant_host_cert_status ON platform.tenant_host_cert USING btree (status);


--
-- Name: idx_tenant_subscription; Type: INDEX; Schema: platform; Owner: app_advertisement
--

CREATE INDEX idx_tenant_subscription ON platform.tenant USING btree (central_subscription_id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE INDEX flyway_schema_history_s_idx ON t_exemplo.flyway_schema_history USING btree (success);


--
-- Name: ix_delivery_screen; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE INDEX ix_delivery_screen ON t_exemplo.delivery USING btree (fk_id_screen, created_at DESC);


--
-- Name: ix_media_sha256; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE INDEX ix_media_sha256 ON t_exemplo.media USING btree (sha256);


--
-- Name: ix_screen_command_pending; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE INDEX ix_screen_command_pending ON t_exemplo.screen_command USING btree (fk_id_screen, status);


--
-- Name: ix_screen_media_screen; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE INDEX ix_screen_media_screen ON t_exemplo.screen_media USING btree (fk_id_screen);


--
-- Name: ux_playlist_origin; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_playlist_origin ON t_exemplo.playlist USING btree (fk_id_originscreen, origin_local_id) WHERE (fk_id_originscreen IS NOT NULL);


--
-- Name: ux_schedule_origin; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_schedule_origin ON t_exemplo.schedule USING btree (fk_id_originscreen, origin_local_id) WHERE (fk_id_originscreen IS NOT NULL);


--
-- Name: ux_screen_snapshot_screen; Type: INDEX; Schema: t_exemplo; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_screen_snapshot_screen ON t_exemplo.screen_snapshot USING btree (fk_id_screen);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE INDEX flyway_schema_history_s_idx ON t_iuri.flyway_schema_history USING btree (success);


--
-- Name: ix_delivery_screen; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE INDEX ix_delivery_screen ON t_iuri.delivery USING btree (fk_id_screen, created_at DESC);


--
-- Name: ix_media_sha256; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE INDEX ix_media_sha256 ON t_iuri.media USING btree (sha256);


--
-- Name: ix_screen_command_pending; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE INDEX ix_screen_command_pending ON t_iuri.screen_command USING btree (fk_id_screen, status);


--
-- Name: ix_screen_media_screen; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE INDEX ix_screen_media_screen ON t_iuri.screen_media USING btree (fk_id_screen);


--
-- Name: ux_playlist_origin; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_playlist_origin ON t_iuri.playlist USING btree (fk_id_originscreen, origin_local_id) WHERE (fk_id_originscreen IS NOT NULL);


--
-- Name: ux_schedule_origin; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_schedule_origin ON t_iuri.schedule USING btree (fk_id_originscreen, origin_local_id) WHERE (fk_id_originscreen IS NOT NULL);


--
-- Name: ux_screen_snapshot_screen; Type: INDEX; Schema: t_iuri; Owner: app_advertisement
--

CREATE UNIQUE INDEX ux_screen_snapshot_screen ON t_iuri.screen_snapshot USING btree (fk_id_screen);


--
-- Name: demo_lead fk_demo_lead_session; Type: FK CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_lead
    ADD CONSTRAINT fk_demo_lead_session FOREIGN KEY (session_id) REFERENCES platform.demo_session(id);


--
-- Name: demo_login_token fk_demo_login_token_session; Type: FK CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_login_token
    ADD CONSTRAINT fk_demo_login_token_session FOREIGN KEY (session_id) REFERENCES platform.demo_session(id);


--
-- Name: demo_sandbox fk_demo_sandbox_tenant; Type: FK CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.demo_sandbox
    ADD CONSTRAINT fk_demo_sandbox_tenant FOREIGN KEY (tenant_id) REFERENCES platform.tenant(id);


--
-- Name: tenant_domain fk_tenant_domain_tenant; Type: FK CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_domain
    ADD CONSTRAINT fk_tenant_domain_tenant FOREIGN KEY (tenant_id) REFERENCES platform.tenant(id);


--
-- Name: tenant_host_cert fk_tenant_host_cert_tenant; Type: FK CONSTRAINT; Schema: platform; Owner: app_advertisement
--

ALTER TABLE ONLY platform.tenant_host_cert
    ADD CONSTRAINT fk_tenant_host_cert_tenant FOREIGN KEY (tenant_id) REFERENCES platform.tenant(id);


--
-- Name: delivery fk_from_tbdelivery_for_tbappuser; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.delivery
    ADD CONSTRAINT fk_from_tbdelivery_for_tbappuser FOREIGN KEY (fk_id_sentby) REFERENCES t_exemplo.app_user(id) ON DELETE SET NULL;


--
-- Name: delivery fk_from_tbdelivery_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.delivery
    ADD CONSTRAINT fk_from_tbdelivery_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_exemplo.screen(id) ON DELETE CASCADE;


--
-- Name: media fk_from_tbmedia_for_tbappuser; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media
    ADD CONSTRAINT fk_from_tbmedia_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_exemplo.app_user(id) ON DELETE SET NULL;


--
-- Name: media_upload fk_from_tbmediaupload_for_tbappuser; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.media_upload
    ADD CONSTRAINT fk_from_tbmediaupload_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_exemplo.app_user(id) ON DELETE SET NULL;


--
-- Name: password_token fk_from_tbpasswordtoken_for_tbappuser; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.password_token
    ADD CONSTRAINT fk_from_tbpasswordtoken_for_tbappuser FOREIGN KEY (fk_id_user) REFERENCES t_exemplo.app_user(id) ON DELETE CASCADE;


--
-- Name: playlist fk_from_tbplaylist_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.playlist
    ADD CONSTRAINT fk_from_tbplaylist_for_tbscreen FOREIGN KEY (fk_id_originscreen) REFERENCES t_exemplo.screen(id) ON DELETE SET NULL;


--
-- Name: schedule fk_from_tbschedule_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.schedule
    ADD CONSTRAINT fk_from_tbschedule_for_tbplaylist FOREIGN KEY (fk_id_playlist) REFERENCES t_exemplo.playlist(id);


--
-- Name: schedule fk_from_tbschedule_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.schedule
    ADD CONSTRAINT fk_from_tbschedule_for_tbscreen FOREIGN KEY (fk_id_originscreen) REFERENCES t_exemplo.screen(id) ON DELETE SET NULL;


--
-- Name: screen fk_from_tbscreen_for_tbdelivery; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbdelivery FOREIGN KEY (fk_id_currentdelivery) REFERENCES t_exemplo.delivery(id) ON DELETE SET NULL;


--
-- Name: screen fk_from_tbscreen_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbplaylist FOREIGN KEY (fk_id_defaultplaylist) REFERENCES t_exemplo.playlist(id);


--
-- Name: screen fk_from_tbscreen_for_tbscreengroup; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbscreengroup FOREIGN KEY (fk_id_group) REFERENCES t_exemplo.screen_group(id) ON DELETE SET NULL;


--
-- Name: screen_command fk_from_tbscreencommand_for_tbappuser; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_command
    ADD CONSTRAINT fk_from_tbscreencommand_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_exemplo.app_user(id) ON DELETE SET NULL;


--
-- Name: screen_command fk_from_tbscreencommand_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_command
    ADD CONSTRAINT fk_from_tbscreencommand_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_exemplo.screen(id) ON DELETE CASCADE;


--
-- Name: screen_group fk_from_tbscreengroup_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_group
    ADD CONSTRAINT fk_from_tbscreengroup_for_tbplaylist FOREIGN KEY (fk_id_defaultplaylist) REFERENCES t_exemplo.playlist(id);


--
-- Name: screen_media fk_from_tbscreenmedia_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_media
    ADD CONSTRAINT fk_from_tbscreenmedia_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_exemplo.screen(id) ON DELETE CASCADE;


--
-- Name: screen_snapshot fk_from_tbscreensnapshot_for_tbscreen; Type: FK CONSTRAINT; Schema: t_exemplo; Owner: app_advertisement
--

ALTER TABLE ONLY t_exemplo.screen_snapshot
    ADD CONSTRAINT fk_from_tbscreensnapshot_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_exemplo.screen(id) ON DELETE CASCADE;


--
-- Name: delivery fk_from_tbdelivery_for_tbappuser; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.delivery
    ADD CONSTRAINT fk_from_tbdelivery_for_tbappuser FOREIGN KEY (fk_id_sentby) REFERENCES t_iuri.app_user(id) ON DELETE SET NULL;


--
-- Name: delivery fk_from_tbdelivery_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.delivery
    ADD CONSTRAINT fk_from_tbdelivery_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_iuri.screen(id) ON DELETE CASCADE;


--
-- Name: media fk_from_tbmedia_for_tbappuser; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media
    ADD CONSTRAINT fk_from_tbmedia_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_iuri.app_user(id) ON DELETE SET NULL;


--
-- Name: media_upload fk_from_tbmediaupload_for_tbappuser; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.media_upload
    ADD CONSTRAINT fk_from_tbmediaupload_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_iuri.app_user(id) ON DELETE SET NULL;


--
-- Name: password_token fk_from_tbpasswordtoken_for_tbappuser; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.password_token
    ADD CONSTRAINT fk_from_tbpasswordtoken_for_tbappuser FOREIGN KEY (fk_id_user) REFERENCES t_iuri.app_user(id) ON DELETE CASCADE;


--
-- Name: playlist fk_from_tbplaylist_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.playlist
    ADD CONSTRAINT fk_from_tbplaylist_for_tbscreen FOREIGN KEY (fk_id_originscreen) REFERENCES t_iuri.screen(id) ON DELETE SET NULL;


--
-- Name: schedule fk_from_tbschedule_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.schedule
    ADD CONSTRAINT fk_from_tbschedule_for_tbplaylist FOREIGN KEY (fk_id_playlist) REFERENCES t_iuri.playlist(id);


--
-- Name: schedule fk_from_tbschedule_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.schedule
    ADD CONSTRAINT fk_from_tbschedule_for_tbscreen FOREIGN KEY (fk_id_originscreen) REFERENCES t_iuri.screen(id) ON DELETE SET NULL;


--
-- Name: screen fk_from_tbscreen_for_tbdelivery; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbdelivery FOREIGN KEY (fk_id_currentdelivery) REFERENCES t_iuri.delivery(id) ON DELETE SET NULL;


--
-- Name: screen fk_from_tbscreen_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbplaylist FOREIGN KEY (fk_id_defaultplaylist) REFERENCES t_iuri.playlist(id);


--
-- Name: screen fk_from_tbscreen_for_tbscreengroup; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen
    ADD CONSTRAINT fk_from_tbscreen_for_tbscreengroup FOREIGN KEY (fk_id_group) REFERENCES t_iuri.screen_group(id) ON DELETE SET NULL;


--
-- Name: screen_command fk_from_tbscreencommand_for_tbappuser; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_command
    ADD CONSTRAINT fk_from_tbscreencommand_for_tbappuser FOREIGN KEY (fk_id_createdby) REFERENCES t_iuri.app_user(id) ON DELETE SET NULL;


--
-- Name: screen_command fk_from_tbscreencommand_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_command
    ADD CONSTRAINT fk_from_tbscreencommand_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_iuri.screen(id) ON DELETE CASCADE;


--
-- Name: screen_group fk_from_tbscreengroup_for_tbplaylist; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_group
    ADD CONSTRAINT fk_from_tbscreengroup_for_tbplaylist FOREIGN KEY (fk_id_defaultplaylist) REFERENCES t_iuri.playlist(id);


--
-- Name: screen_media fk_from_tbscreenmedia_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_media
    ADD CONSTRAINT fk_from_tbscreenmedia_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_iuri.screen(id) ON DELETE CASCADE;


--
-- Name: screen_snapshot fk_from_tbscreensnapshot_for_tbscreen; Type: FK CONSTRAINT; Schema: t_iuri; Owner: app_advertisement
--

ALTER TABLE ONLY t_iuri.screen_snapshot
    ADD CONSTRAINT fk_from_tbscreensnapshot_for_tbscreen FOREIGN KEY (fk_id_screen) REFERENCES t_iuri.screen(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xJcy8HUzLOV5mp6tcQPdHFKVxHcFXfQR8kcFWw3Ks8BQPhRlUbg4ZXAlyMhI1QC

